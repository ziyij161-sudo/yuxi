# ==========================================
# 引火求援小游戏
# Ren'Py 8.5.3
# ==========================================
# 分辨率由 game_01/game_05 统一设定为 1920x1080，此处不再重复定义

default fire_level = 0
default torch_hint = "点击士兵，引起他们的注意！"
default game_timer = 60.0  # 游戏总限时60秒

# ==========================================
# 图片素材【已补齐dark_grass_bg】
# ==========================================
image night_bg = "images/game_04/night_bg.png"
image dark_grass_bg = "images/game_04/night_bg.png"
image grass_front = "images/game_04/grass_front.png"

# ==========================================
# 士兵行走动画
# ==========================================
image soldier_walk:
    "images/game_04/soldier_1.png"
    pause 0.12
    "images/game_04/soldier_2.png"
    pause 0.12
    "images/game_04/soldier_3.png"
    pause 0.12
    "images/game_04/soldier_4.png"
    pause 0.12
    repeat

# ==========================================
# 士兵移动路线
# ==========================================
transform march_1:
    xpos -0.20
    ypos 0.44
    linear 17.0 xpos 1.20
    xpos -0.20
    repeat

transform march_2:
    xpos 0.05
    ypos 0.47
    linear 16.0 xpos 1.20
    xpos -0.20
    repeat

transform march_3:
    xpos 0.30
    ypos 0.45
    linear 18.0 xpos 1.20
    xpos -0.20
    repeat

transform march_4:
    xpos 0.55
    ypos 0.49
    linear 17.0 xpos 1.20
    xpos -0.20
    repeat

transform march_5:
    xpos 0.80
    ypos 0.46
    linear 16.0 xpos 1.20
    xpos -0.20
    repeat

transform march_6:
    xpos -0.10
    ypos 0.57
    linear 19.0 xpos 1.20
    xpos -0.20
    repeat

transform march_7:
    xpos 0.35
    ypos 0.59
    linear 18.0 xpos 1.20
    xpos -0.20
    repeat

transform march_8:
    xpos 0.75
    ypos 0.56
    linear 17.0 xpos 1.20
    xpos -0.20
    repeat

# ==========================================
# 点击士兵
# ==========================================
init python:
    def click_soldier():
        if store.fire_level >= 5:
            return
        store.fire_level += 1
        # 音效容错，文件不存在不崩溃
        try:
            renpy.sound.play("audio/audio_04/click.ogg")
        except:
            pass

        x, y = renpy.get_mouse_pos()
        y = max(50, y - 65)
        renpy.show_screen("soldier_popup", x=x, y=y)

        if store.fire_level >= 5:
            store.fire_level = 5
            store.torch_hint = "成功了！他们发现你了！"
        else:
            store.torch_hint = "好像在那边……"

# ==========================================
# 弹窗动画
# ==========================================
screen soldier_popup(x, y):
    text "好像在那边……":
        xpos x
        ypos y
        anchor (0.5, 1.0)
        size 36
        color "#FFF3C4"
        outlines [(3, "#382B20", 0, 0)]
        at popup_effect
    timer 0.8 action Hide("soldier_popup")

transform popup_effect:
    alpha 0.0
    yoffset 15
    ease 0.15 alpha 1.0 yoffset 0
    pause 0.5
    ease 0.15 alpha 0.0

# ==========================================
# 小游戏界面
# ==========================================
screen torch_game_screen():
    # 8个士兵按钮
    button:
        xysize (150, 150)
        background None
        hover_background None
        at march_1
        sensitive fire_level < 5
        action Function(click_soldier)
        add "soldier_walk":
            xalign 0.5
            yalign 0.5
            zoom 0.10

    button:
        xysize (150, 150)
        background None
        hover_background None
        at march_2
        sensitive fire_level < 5
        action Function(click_soldier)
        add "soldier_walk":
            xalign 0.5
            yalign 0.5
            zoom 0.09

    button:
        xysize (150, 150)
        background None
        hover_background None
        at march_3
        sensitive fire_level < 5
        action Function(click_soldier)
        add "soldier_walk":
            xalign 0.5
            yalign 0.5
            zoom 0.10

    button:
        xysize (150, 150)
        background None
        hover_background None
        at march_4
        sensitive fire_level < 5
        action Function(click_soldier)
        add "soldier_walk":
            xalign 0.5
            yalign 0.5
            zoom 0.085

    button:
        xysize (150, 150)
        background None
        hover_background None
        at march_5
        sensitive fire_level < 5
        action Function(click_soldier)
        add "soldier_walk":
            xalign 0.5
            yalign 0.5
            zoom 0.09

    button:
        xysize (150, 150)
        background None
        hover_background None
        at march_6
        sensitive fire_level < 5
        action Function(click_soldier)
        add "soldier_walk":
            xalign 0.5
            yalign 0.5
            zoom 0.085

    button:
        xysize (150, 150)
        background None
        hover_background None
        at march_7
        sensitive fire_level < 5
        action Function(click_soldier)
        add "soldier_walk":
            xalign 0.5
            yalign 0.5
            zoom 0.08

    button:
        xysize (150, 150)
        background None
        hover_background None
        at march_8
        sensitive fire_level < 5
        action Function(click_soldier)
        add "soldier_walk":
            xalign 0.5
            yalign 0.5
            zoom 0.085

    add "grass_front":
        xysize (config.screen_width, config.screen_height)

    text "引火求援":
        xalign 0.5
        ypos 0.04
        size 54
        color "#e8d5a3"
        outlines [(2, "#332719", 0, 0)]

    vbox:
        xalign 0.5
        ypos 0.14
        spacing 12
        text "引起士兵注意：[fire_level]/5":
            size 34
            color "#FFE1A0"
            outlines [(2, "#332719", 0, 0)]
        bar:
            value fire_level
            range 5
            xsize 300
            ysize 16
        text "剩余时间：[int(game_timer)]秒":
            size 32
            color "#FFDDAA"
            outlines [(2, "#332719",0,0)]

    text torch_hint:
        xalign 0.5
        yalign 0.91
        size 38
        color "#FFF2D5"
        outlines [(2, "#332719", 0, 0)]

    # ---------- 右上角：重置 / 跳过（与第一章规格一致） ----------
    hbox:
        xalign 0.985
        ypos 32
        spacing 26
        textbutton "重 置":
            style "game_button"
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            action [
                Hide("soldier_popup"),
                SetVariable("fire_level", 0),
                SetVariable("game_timer", 60.0),
                SetVariable("torch_hint", "点击士兵，引起他们的注意！"),
            ]
        textbutton "跳 过":
            style "game_button"
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            action [Hide("soldier_popup"), Jump("torch_skip")]

# ==========================================
# 结算卡片（成功 / 失败共用）
# ==========================================
screen torch_result(title, title_color, line1, line2):
    modal True

    button:
        xfill True
        yfill True
        background None
        action Return()

    frame:
        xalign 0.5
        yalign 0.5
        xmaximum 1100
        background "#0d0a07e6"
        padding (100, 60)

        vbox:
            xalign 0.5
            spacing 22

            text title:
                xalign 0.5
                size 68
                color title_color

            text line1:
                xalign 0.5
                size 38
                color "#cbb98f"

            text line2:
                xalign 0.5
                size 32
                color "#8f7f5e"

            null height 6

            text "（点击任意处继续）":
                xalign 0.5
                size 24
                color "#8f7f5e"

# ==========================================
# 第四章入口
# ==========================================
label game_04_entry:
    # 第四章开场视频（videos/ch04.webm，可暂停 / 倍速 / 跳过）
    call play_chapter_movie(4)
    scene dark_grass_bg
    with fade

    # 夜色江边的环境底噪（要换音乐，直接替换 audio/game_04/night_river.ogg 同名文件）
    play music "audio/game_04/night_river.ogg" fadein 2.0 loop

    call screen chapter_intro(
        "引火求援",
        "公元 552 年　・　长江北岸",
        [
            "侯景败了。城破之前，他交代手下：我死了，就把这枚玺沉进长江。",
            "夜里，我被草草扔在江边的荒草里，等待士兵发现。",
        ],
        [
            "点击巡逻的士兵，吸引他们的注意。",
            "六十秒内引起五次注意，他们才会朝草丛走来。",
        ],
    )

    # 开场旁白：底部对话框（与第一章同一规格）
    call screen story_dialog("夜色渐深，草丛里一片寂静。")
    call screen story_dialog("草叶上的露水浸透了我。石头是凉的，可我总想起自己被刻出来的那个下午——御案上的烛火很暖。")
    call screen story_dialog("远处有火把在动。一队士兵沿着江北岸巡逻。")
    call screen story_dialog("只要他们肯往这片草丛多看一眼，我就不必忍受黑暗。")
    jump torch_game

# ==========================================
# 小游戏主体（加入倒计时）
# ==========================================
label torch_game:
    $ fire_level = 0
    $ torch_hint = "点击士兵，引起他们的注意！"
    $ game_timer = 60.0

    scene night_bg
    with fade

    show screen torch_game_screen

    while fire_level < 5 and game_timer > 0:
        $ game_timer -= 0.1
        pause 0.1

    hide screen torch_game_screen
    hide screen soldier_popup

    if fire_level >= 5:
        jump fire_success
    else:
        jump fire_fail

# ==========================================
# 成功结局
# ==========================================
label fire_success:
    hide screen torch_game_screen
    hide screen soldier_popup
    scene dark_grass_bg
    with fade
    stop music fadeout 3.0
    # 小游戏结束，接回全篇统一配乐
    play music "audio/common/calm.ogg" fadein 2.0 loop
    call screen torch_result("求援成功！", "#FFD76A", "远处的士兵终于发现了你！", "他们举着火把，朝这片草丛走来。")
    "脚步声由远及近。有人拨开草叶，火光落在我身上。"
    "“是玉玺！”他蹲下来，把我从泥里抠出来，用袖子擦了擦。"
    "那一夜的江水很急。我没有沉下去。"
    # ★ 已接入主线：进入千年流转章（game_05.rpy 的 label game_06）
    jump game_06

# ==========================================
# 新增：超时失败结局
# ==========================================
label fire_fail:
    hide screen torch_game_screen
    hide screen soldier_popup
    scene dark_grass_bg
    with fade
    stop music fadeout 3.0
    # 小游戏结束，接回全篇统一配乐
    play music "audio/common/calm.ogg" fadein 2.0 loop
    call screen torch_result("求援失败", "#e88a8a", "时间流逝，巡逻的士兵走远了。", "再也没有人听见草丛里的动静。")
    "天快亮的时候，来了两个侯景的旧部。"
    "他们把我从草里捡起来，看了看，塞进一只布袋。"
    "长江的水很急。我沉下去的时候，最后看见的是一线灰白的天。"
    # ★ 已接入主线：进入千年流转章（game_05.rpy 的 label game_06）
    jump game_06

# ==========================================
# 跳过：直接离开小游戏
# ==========================================
label torch_skip:
    hide screen torch_game_screen
    hide screen soldier_popup
    scene dark_grass_bg
    with fade
    stop music fadeout 3.0
    # 小游戏结束，接回全篇统一配乐
    play music "audio/common/calm.ogg" fadein 2.0 loop
    "我没有再等下去，任由夜色把草丛重新合拢。"
    "天亮时，士兵发现了我"
    # ★ 已接入主线：进入千年流转章（game_05.rpy 的 label game_06）
    jump game_06

# ==========================================
# （原 game_final 收尾段已移除：收尾台词并入 game_05 的 cx_after，
#   章节顺序为 引火求援 → 千年流转 → 番外）
# ==========================================