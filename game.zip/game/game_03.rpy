# ========== 关卡3：水中躲避 ==========
default shui_x = 960
default shui_wanhao = 3
default shui_jieshu = False

default s1_drop = 0
default s2_drop = 0
default s3_drop = 0
default s4_drop = 0
default s5_drop = 0

default s1_x = 960
default s1_y = -100
default s1_active = True
default s2_x = 400
default s2_y = -300
default s2_active = True
default s3_x = 700
default s3_y = -500
default s3_active = True
default s4_x = 200
default s4_y = -700
default s4_active = True
default s5_x = 900
default s5_y = -900
default s5_active = True

init python:
    # 重置本关全部状态（右上角“重 置”按钮调用）
    def shui_reset():
        store.shui_x = 960
        store.shui_wanhao = 3
        store.shui_jieshu = False
        init_pos = [(960, -100), (200, -500), (1500, -900), (1100, -1300), (400, -1800)]
        for i, (x, y) in enumerate(init_pos, start=1):
            setattr(store, "s{}_drop".format(i), 0)
            setattr(store, "s{}_x".format(i), x)
            setattr(store, "s{}_y".format(i), y)
            setattr(store, "s{}_active".format(i), True)

screen shuizhong_minigame():
    modal True
    zorder 100

    add "images/game_03/bg_water.png" xysize (config.screen_width, config.screen_height)
    # 第三章目录里没有 yuxi_crack.png，复用第二章的玉玺图（原图很大，用 zoom 缩到约 800px 宽）
    add "images/game_02/yuxi_crack.png" zoom 0.1 xpos shui_x ypos 550 xanchor 0.5 yanchor 0.5

    if s1_active:
        add "images/game_03/stone1.png" zoom 0.07 xpos s1_x ypos s1_y xanchor 0.5 yanchor 0.5
    if s2_active:
        add "images/game_03/stone2.png" zoom 0.1 xpos s2_x ypos s2_y xanchor 0.5 yanchor 0.5
    if s3_active:
        add "images/game_03/stone3.png" zoom 0.08 xpos s3_x ypos s3_y xanchor 0.5 yanchor 0.5
    if s4_active:
        add "images/game_03/stone4.png" zoom 0.1 xpos s4_x ypos s4_y xanchor 0.5 yanchor 0.5
    if s5_active:
        add "images/game_03/stone5.png" zoom 0.25 xpos s5_x ypos s5_y xanchor 0.5 yanchor 0.5

    text "玉玺完好度：[shui_wanhao]":
        xalign 0.1
        yalign 0.05
        size 38
        color "#e8d5a3"
        outlines [(2, "#000000", 0, 0)]

    # ---------- 右上角：重置 / 跳过（与第一章规格一致） ----------
    hbox:
        xalign 0.985
        ypos 32
        spacing 26
        textbutton "重 置":
            style "game_button"
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            action Function(shui_reset)
        textbutton "跳 过":
            style "game_button"
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            action Return("跳过")

    textbutton "←":
        style "game_button"
        xalign 0.1
        yalign 0.85
        xysize (132, 132)
        text_size 64
        text_color "#e8d5a3"
        text_hover_color "#ffffff"
        text_xalign 0.5
        text_yalign 0.5
        action SetVariable("shui_x", max(300, shui_x - 60))

    textbutton "→":
        style "game_button"
        xalign 0.9
        yalign 0.85
        xysize (132, 132)
        text_size 64
        text_color "#e8d5a3"
        text_hover_color "#ffffff"
        text_xalign 0.5
        text_yalign 0.5
        action SetVariable("shui_x", min(config.screen_width - 300, shui_x + 60))

    timer 0.05 repeat True:
        action If(
            not shui_jieshu,
            [
                If(s1_active, [
                    SetVariable("s1_y", s1_y + 12), 
                    If(s1_y > config.screen_height, [
                        SetVariable("s1_drop", s1_drop + 1),
                        If(s1_drop >= 2, SetVariable("s1_active", False), [
                            SetVariable("s1_y", -150), SetVariable("s1_x", renpy.random.randint(100, config.screen_width - 100))
                        ])
                    ]),
                    If(abs(s1_x - shui_x) < 250 and abs(s1_y - 550) < 160, [
                        Play("sound", "audio/game_03/crash.wav"), SetVariable("shui_wanhao", shui_wanhao - 1), SetVariable("s1_active", False)
                    ])
                ]),

                If(s2_active, [
                    SetVariable("s2_y", s2_y + 15), 
                    If(s2_y > config.screen_height, [
                        SetVariable("s2_drop", s2_drop + 1),
                        If(s2_drop >= 2, SetVariable("s2_active", False), [
                            SetVariable("s2_y", -200), SetVariable("s2_x", renpy.random.randint(100, config.screen_width - 100))
                        ])
                    ]),
                    If(abs(s2_x - shui_x) < 230 and abs(s2_y - 550) < 150, [
                        Play("sound", "audio/game_03/crash.wav"), SetVariable("shui_wanhao", shui_wanhao - 1), SetVariable("s2_active", False)
                    ])
                ]),

                If(s3_active, [
                    SetVariable("s3_y", s3_y + 10), 
                    If(s3_y > config.screen_height, [
                        SetVariable("s3_drop", s3_drop + 1),
                        If(s3_drop >= 2, SetVariable("s3_active", False), [
                            SetVariable("s3_y", -250), SetVariable("s3_x", renpy.random.randint(100, config.screen_width - 100))
                        ])
                    ]),
                    If(abs(s3_x - shui_x) < 220 and abs(s3_y - 550) < 180, [
                        Play("sound", "audio/game_03/crash.wav"), SetVariable("shui_wanhao", shui_wanhao - 1), SetVariable("s3_active", False)
                    ])
                ]),

                If(s4_active, [
                    SetVariable("s4_y", s4_y + 18), 
                    If(s4_y > config.screen_height, [
                        SetVariable("s4_drop", s4_drop + 1),
                        If(s4_drop >= 2, SetVariable("s4_active", False), [
                            SetVariable("s4_y", -300), SetVariable("s4_x", renpy.random.randint(100, config.screen_width - 100))
                        ])
                    ]),
                    If(abs(s4_x - shui_x) < 220 and abs(s4_y - 550) < 160, [
                        Play("sound", "audio/game_03/crash.wav"), SetVariable("shui_wanhao", shui_wanhao - 1), SetVariable("s4_active", False)
                    ])
                ]),

                If(s5_active, [
                    SetVariable("s5_y", s5_y + 14), 
                    If(s5_y > config.screen_height, [
                        SetVariable("s5_drop", s5_drop + 1),
                        If(s5_drop >= 2, SetVariable("s5_active", False), [
                            SetVariable("s5_y", -150), SetVariable("s5_x", renpy.random.randint(100, config.screen_width - 100))
                        ])
                    ]),
                    If(abs(s5_x - shui_x) < 180 and abs(s5_y - 550) < 130, [
                        Play("sound", "audio/game_03/crash.wav"), SetVariable("shui_wanhao", shui_wanhao - 1), SetVariable("s5_active", False)
                    ])
                ]),

                If(shui_wanhao <= 0, [SetVariable("shui_jieshu", True), Return("失败")]),
                If(not s1_active and not s2_active and not s3_active and not s4_active and not s5_active, [SetVariable("shui_jieshu", True), Return("成功")])
            ]
        )

label game_03_entry:
    # 第三章开场视频（videos/ch03.webm，可暂停 / 倍速 / 跳过）
    call play_chapter_movie(3)
    # 视频期间音乐淡出，播完接回全篇统一配乐
    play music "audio/common/calm.ogg" fadein 2.0 loop
    $ shui_x = 960
    $ shui_wanhao = 3
    $ shui_jieshu = False
    $ s1_drop = 0
    $ s2_drop = 0
    $ s3_drop = 0
    $ s4_drop = 0
    $ s5_drop = 0
    $ s1_x = 960
    $ s1_y = -100
    $ s1_active = True
    $ s2_x = 200
    $ s2_y = -500
    $ s2_active = True
    $ s3_x = 1500
    $ s3_y = -900
    $ s3_active = True
    $ s4_x = 1100
    $ s4_y = -1300
    $ s4_active = True
    $ s5_x = 400
    $ s5_y = -1800
    $ s5_active = True

    scene expression Transform("images/game_03/bg_water.png", xysize=(config.screen_width, config.screen_height))
    with fade

    call screen chapter_intro(
        "井  底",
        "公元 189 年　・　洛阳",
        [
            "十常侍挟着少帝出宫，洛阳的大火烧了三天。",
            "我被裹在绢里，跟着一群人逃命；跑到城南，抱着我的人把我扔到了井里。",
        ],
        [
            "用「←」「→」左右移动，躲开水里坠下的碎石。",
            "完好度归零，我便碎在井底；撑到石头落尽，才有重见天日的那天。",
        ],
    )

    "井水很冷，冷得我身上的刻痕都缩了一下。"
    "头顶那一方天，被火光照得通红。"
    "抱着我的人再也没有浮上去。我沉在井底，身上压着半块断砖。"

    play music "audio/game_03/4_bgm.wav" fadein 1.0 loop
    play sound "audio/game_03/underwater_ambient.wav" loop fadein 1.0

    call screen shuizhong_minigame

    $ jieguo4 = _return
    stop music fadeout 2.0
    stop sound fadeout 2.0
    # 小游戏结束，接回全篇统一配乐
    play music "audio/common/calm.ogg" fadein 2.0 loop

    scene expression Transform("images/game_03/bg_water.png", xysize=(config.screen_width, config.screen_height))
    with dissolve
    
    if jieguo4 == "成功":
        "石头终于落尽。我躺在淤泥里，听见头顶有人在喊。"
        "191 年，孙坚的兵士看见城南甄官井上冒起五色气——他们放下绳索，把我捞了上来。"
    elif jieguo4 == "跳过":
        "我没有再躲闪，任由碎石落下——反正裂痕早就够多了。"
        "后来孙坚的兵士把我从井里捞起时，我身上又多了几道洗不掉的白痕。"
    else:
        "碎石一次次砸在我的身上。我听见自己裂开的声音，像谁在很远的地方叹气。"
        "可我还是没有碎。孙坚的兵士把我从井里捞起来时，我只剩下半条命。"


    # ★ 已接入主线：进入第四章（引火求援，公元 552 年・长江北岸）
    jump game_04_entry