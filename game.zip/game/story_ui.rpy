# ============================================================
# 《假如你是传国玉玺》—— 全局叙事界面
#   1. title_card      游戏片头（点开始后、第一段视频之前）
#   2. chapter_intro   每章开场介绍卡（标题 / 时间地点 / 剧情引子 / 玩法规则）
#   3. story_dialog    底部对话框（与第一章 kezi_dialog 完全同一规格）
#
# ⚠ 语音统一：本作全篇为玉玺第一视角（"我"），
#   界面上的规则说明才用"你"称呼玩家。
# ============================================================

init python:
    STORY_FONT = "SourceHanSansLite.ttf"

    # ---------- 片头年表（标题页底部） ----------
    STORY_CHRONICLE = "前221  ・  前9  ・  23  ・  189  ・  552  ・  936"


transform story_fade_in:
    alpha 0.0
    ease 0.8 alpha 1.0

transform story_blink:
    alpha 0.30
    linear 1.3 alpha 1.00
    linear 1.3 alpha 0.30
    repeat


# ============================================================
# 片头：游戏名
# ============================================================
screen title_card():
    modal True
    zorder 500

    # 片头时隐藏底部「回退/历史/快进」快捷菜单
    on "show" action SetVariable("quick_menu", False)
    on "hide" action SetVariable("quick_menu", True)

    # 深色底 + 极淡的玉玺印记
    add Solid("#0a0806")

    if renpy.loadable("images_01/seal.png"):
        add "images_01/seal.png":
            xalign 0.5
            yalign 0.42
            xysize (900, 506)
            alpha 0.10

    # 点击任意处 / 按任意键进入
    button:
        xfill True
        yfill True
        background None
        action Return()

    key "K_RETURN" action Return()
    key "K_SPACE" action Return()

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 30
        at story_fade_in

        # 八字铭文
        text "受 命 于 天     既 寿 永 昌":
            xalign 0.5
            font STORY_FONT
            size 40
            color "#7d6b4a"

        null height 10

        # 游戏名
        text "假如你是传国玉玺":
            xalign 0.5
            font STORY_FONT
            size 104
            color "#e8d5a3"
            outlines [(3, "#1a1208", 0, 0)]

        # 金色分隔线
        frame:
            xalign 0.5
            xysize (620, 2)
            background "#6b5734"

        text "以一方玉玺的眼睛，看两千年王朝更替":
            xalign 0.5
            font STORY_FONT
            size 34
            color "#a8946c"

    # 底部年表
    text STORY_CHRONICLE:
        xalign 0.5
        yalign 0.88
        font STORY_FONT
        size 26
        color "#5c4f38"

    text "（点击任意处开始）":
        xalign 0.5
        yalign 0.95
        font STORY_FONT
        size 26
        color "#8f7f5e"
        at story_blink


# ============================================================
# 章节开场卡：引言式排版（标题 / 时间地点 / 剧情 / 规则）
# ============================================================
screen chapter_intro(title, era, sub, rules):
    modal True
    zorder 400

    on "show" action SetVariable("quick_menu", False)
    on "hide" action SetVariable("quick_menu", True)

    button:
        xfill True
        yfill True
        background None
        action Return()

    key "K_RETURN" action Return()
    key "K_SPACE" action Return()

    frame:
        xalign 0.5
        yalign 0.5
        xmaximum 1300
        background "#0d0a07e6"
        padding (100, 62)

        vbox:
            xalign 0.5
            spacing 22

            # 章节名
            text title:
                xalign 0.5
                font STORY_FONT
                size 82
                color "#e8d5a3"
                outlines [(2, "#1a1208", 0, 0)]

            # 时间 ・ 地点
            text era:
                xalign 0.5
                font STORY_FONT
                size 32
                color "#8f7f5e"

            null height 12

            # 剧情引子（第一人称，玉玺自述）
            for s in sub:
                text s:
                    xalign 0.5
                    text_align 0.5
                    font STORY_FONT
                    size 40
                    color "#cbb98f"

            null height 14

            # 分隔线
            frame:
                xalign 0.5
                xysize (480, 1)
                background "#7a6440"

            # 玩法规则
            for r in rules:
                text r:
                    xalign 0.5
                    text_align 0.5
                    font STORY_FONT
                    size 30
                    color "#a8946c"

            null height 6

            text "（点击任意处开始）":
                xalign 0.5
                font STORY_FONT
                size 24
                color "#7d6d52"
                at story_blink


# ============================================================
# 底部对话框（与第一章 kezi_dialog 同规格）
# ============================================================
screen story_dialog(txt):
    modal True
    zorder 300

    on "show" action SetVariable("quick_menu", False)
    on "hide" action SetVariable("quick_menu", True)

    button:
        xfill True
        yfill True
        background None
        action Return()

    frame:
        xalign 0.5
        yalign 0.92
        xmaximum 1640
        background "#0d0a07e6"
        padding (70, 36)

        vbox:
            spacing 10
            text "[txt]":
                font STORY_FONT
                size 48
                color "#e8d5a3"
            text "（点击任意处继续）":
                font STORY_FONT
                size 22
                color "#8f7f5e"


# ============================================================
# 制作名单（「—— 全剧终 ——」之后、回主菜单之前）
# ============================================================
screen credits_card():
    modal True
    zorder 600

    add Solid("#0a0806")

    button:
        xfill True
        yfill True
        background None
        action Return()

    key "K_RETURN" action Return()
    key "K_SPACE" action Return()

    vbox:
        xalign 0.5
        yalign 0.46
        spacing 24
        at story_fade_in

        text "制 作 名 单":
            xalign 0.5
            font STORY_FONT
            size 58
            color "#e8d5a3"
            outlines [(2, "#1a1208", 0, 0)]

        frame:
            xalign 0.5
            xysize (440, 2)
            background "#6b5734"

        null height 6

        text "制作人":
            xalign 0.5
            font STORY_FONT
            size 28
            color "#8f7f5e"

        text "焦子仪   刘宇涵   李瑞":
            xalign 0.5
            font STORY_FONT
            size 46
            color "#dfc993"

        null height 30

        text "受命于天    既寿永昌":
            xalign 0.5
            font STORY_FONT
            size 30
            color "#7d6b4a"

    text "（点击任意处结束）":
        xalign 0.5
        yalign 0.92
        font STORY_FONT
        size 24
        color "#8f7f5e"
        at story_blink
