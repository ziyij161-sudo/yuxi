# ============================================================
# 《假如你是传国玉玺》—— game_01：李斯刻字关卡（单文件整合版）
# game_01.rpy = 原 script.rpy + screens.rpy 合并
# 分辨率：1920 x 1080
#
# 本文件包含：
#   - init python：字体探测、乱码修复、素材索引、音效、震动、点击逻辑
#   - default     ：存档变量
#   - label       ：start 入口 + 刻字关卡全部流程
#   - screen      ：kezi_dialog / kezi_tip / kezi_game
#
# 素材目录（当前工程实际结构，images 与 audio 同层次命名）：
#   - 背景图：game/images_01/bg_yushi.jpeg
#   - 正确字：game/images_01/seal_chars/correct/
#   - 干扰字：game/images_01/seal_chars/distractors/
#   - 音效：  game/audio_01/{carve,correct,pass,reshape,wrong}.ogg
#   - BGM：  game/audio_01/bg.ogg
#
# ★ 不依赖固定目录：启动时扫描整个 game 目录，
#   按『文件名（不含扩展名）』建立索引来找图。也就是说：
#   shou.png 不管放在 game/ 下哪个子文件夹里都能被找到，
#   优先选 seal_chars 相关目录里的，避免和别的同名图混淆。
#
# ⚠ 重要：
#   1. Ren'Py 只在游戏启动时扫描一次文件。
#      开着游戏改代码/放图片后，必须 Shift+R 热重载或完全重启游戏。
#   2. 本文件是唯一代码文件，旧的 script.rpy / screens.rpy
#      （以及 script.rpyc / screens.rpyc 编译残留）必须删除，
#      否则 label start 重名会报错。
# ============================================================

# ============================================================
# 第一部分：逻辑（原 script.rpy）
# ============================================================
init python:
    import os

    # ---------- 分辨率设定（画面自适应的关键） ----------
    # 本游戏所有坐标、字号均按 1920x1080 设计。
    # Ren'Py 会把虚拟分辨率等比缩放到玩家的窗口/全屏大小：
    # 任何屏幕上画面都自动适配、比例不变形、坐标不错位。
    config.screen_width = 1920
    config.screen_height = 1080
    # ---------- 字体自动探测 ----------
    def kezi_get_font():
        # 优先使用项目自带的中文字体（跨平台可用）
        if renpy.loadable("SourceHanSansLite.ttf"):
            return "SourceHanSansLite.ttf"
        if renpy.loadable("msyh.ttc"):
            return "msyh.ttc"
        for p in (
            "C:/Windows/Fonts/msyh.ttc",
            "C:/Windows/Fonts/msyh.ttf",
            "C:/Windows/Fonts/simhei.ttf",
        ):
            if os.path.isfile(p):
                return p
        return "SourceHanSansLite.ttf"
    KEZI_FONT = kezi_get_font()
    # ---------- 修复对话框/菜单中文乱码（小方块） ----------
    # 游戏内的对白（say 语句）用的是 gui 默认字体（通常是 DejaVuSans.ttf，
    # 不含中文字形），所以出现方块。这里把默认字体统一映射为 KEZI_FONT。
    # 注意：font_replacement_map 的键和值都必须是 (字体, 粗体, 斜体) 三元组，
    # 只写字符串会在渲染对白时抛 ValueError（too many values to unpack）。
    for _fname in ("DejaVuSans.ttf", "gui/default-font.ttf"):
        for _bold in (False, True):
            for _italic in (False, True):
                config.font_replacement_map[(_fname, _bold, _italic)] = (KEZI_FONT, False, False)
    # 兼容工程 gui 变量里定义的字体名（若存在）
    for _key in ("text_font", "name_text_font", "interface_text_font"):
        try:
            _f = getattr(gui, _key)
            if _f:
                for _bold in (False, True):
                    for _italic in (False, True):
                        config.font_replacement_map[(_f, _bold, _italic)] = (KEZI_FONT, False, False)
        except Exception:
            pass
    # ---------- 素材路径 ----------
    # 背景图：优先 images_01/bg_yushi.jpeg，找不到回退根目录 bg_yushi.jpeg，
    # 两处都没有时用深色纯色兜底（不会崩溃，只是没有背景图）
    if renpy.loadable("images_01/bg_yushi.jpeg"):
        KEZI_BG = "images_01/bg_yushi.jpeg"
    elif renpy.loadable("bg_yushi.jpeg"):
        KEZI_BG = "bg_yushi.jpeg"
    else:
        KEZI_BG = Solid("#14100b")
    # 正确顺序铭文：受命于天，既寿永昌（8 个字）
    target_list = ["受", "命", "于", "天", "既", "寿", "永", "昌"]
    # 干扰字：当前选用 皇 / 国 / 龙 / 万
    # 可选字见下方 KEZI_DISTRACTOR_PINYIN，想换直接改这一行
    distractor_txt = ["皇", "国", "龙", "万"]
    distractor_img = []  # 留空 = 全部走自动按文件名查找
    # ---------- 正确字：简体字 -> 文件名（不带扩展名，不分大小写） ----------
    KEZI_CORRECT_PINYIN = {
        "受": "shou",
        "命": "ming",
        "于": "yu",
        "天": "tian",
        "既": "ji",
        "寿": "shou2",
        "永": "yong",
        "昌": "chang",
    }
    # ---------- 干扰字：简体字 -> 文件名（12 张干扰图全部建好映射） ----------
    KEZI_DISTRACTOR_PINYIN = {
        "皇": "distractor_huang",
        "国": "distractor_guo",
        "龙": "distractor_long",
        "万": "distractor_wan",
        "宝": "distractor_bao",
        "朝": "distractor_chao",
        "春": "distractor_chun",
        "凤": "distractor_feng",
        "家": "distractor_jia",
        "乐": "distractor_le",
        "李": "distractor_li",
        "受": "distractor_shou",
    }
    # ---------- 扫描整个 game 目录，建立 文件名 -> [路径列表] 索引 ----------
    def kezi_basename_index():
        exts = (".png", ".jpg", ".jpeg", ".webp")
        idx = {}
        for f in renpy.list_files():
            low = f.lower()
            if low.startswith("saves/"):
                continue
            if not low.endswith(exts):
                continue
            base = low.rsplit("/", 1)[-1]
            for e in exts:
                if base.endswith(e):
                    base = base[:-len(e)]
                    break
            idx.setdefault(base, []).append(f)
        return idx
    # ---------- 从候选里挑路径：优先含 prefer 关键字的 ----------
    def kezi_pick(index, base, prefer=None):
        cands = index.get(base)
        if not cands:
            return None
        if prefer:
            for c in cands:
                if prefer in c:
                    return c
        return cands[0]
    # ---------- 匹配：字 -> 图片路径 ----------
    def kezi_match_images_01():
        mapping = {}
        index = kezi_basename_index()
        # 第 1 步：按文件名精确查找（优先 seal_chars 目录）
        for ch, base in KEZI_CORRECT_PINYIN.items():
            p = kezi_pick(index, base, prefer="seal_chars/correct")
            if p:
                mapping[ch] = p
        for ch, base in KEZI_DISTRACTOR_PINYIN.items():
            if ch in distractor_txt and ch not in mapping:
                p = kezi_pick(index, base, prefer="seal_chars/distractors")
                if p:
                    mapping[ch] = p
        # 第 2 步：兜底 —— 文件名对不上时，在所有含 seal 的路径里做包含匹配
        if len(mapping) < len(target_list) + len(distractor_txt):
            exts = (".png", ".jpg", ".jpeg", ".webp")
            files = sorted([f for f in renpy.list_files()
                            if "seal" in f.lower() and f.lower().endswith(exts)])
            used = set(mapping.values())
            all_kws = {}
            all_kws.update({ch: [ch, base] for ch, base in KEZI_CORRECT_PINYIN.items()})
            all_kws.update({ch: [ch, base, base.replace("distractor_", "")]
                            for ch, base in KEZI_DISTRACTOR_PINYIN.items()})
            for ch in target_list + distractor_txt:
                if ch in mapping:
                    continue
                for kw in all_kws.get(ch, [ch]):
                    hit = False
                    for f in files:
                        if f in used:
                            continue
                        if kw in f.lower():
                            mapping[ch] = f
                            used.add(f)
                            hit = True
                            break
                    if hit:
                        break
        return mapping
    # ---------- 小篆显示缩放：512 原图缩小到约 215px，保证互相不遮挡 ----------
    KEZI_CHAR_ZOOM = 0.42
    # ---------- 生成散布槽位（4 列 x 3 行，避开顶部 UI 区域） ----------
    def kezi_slots():
        xs = [250, 690, 1130, 1570]
        ys = [400, 675, 940]
        slots = []
        for y in ys:
            for x in xs:
                jx = renpy.random.randint(-35, 35)
                jy = renpy.random.randint(-15, 15)
                slots.append((x + jx, y + jy))
        return slots
    # ---------- 构建 / 重置本关数据 ----------
    def kezi_build():
        """合并正确字 + 干扰字，匹配图片，随机打乱并分配位置"""
        global all_chars, kezi_progress, kezi_finished
        global kezi_seq, kezi_missing, kezi_target_count
        mapping = kezi_match_images_01()
        chars = []
        # 正确字
        kezi_seq = []
        for ch in target_list:
            img = mapping.get(ch)
            if img:
                chars.append({"txt": ch, "img": img, "is_target": True})
                kezi_seq.append(ch)
            else:
                kezi_missing.append(ch)
        # 干扰字
        for ch in distractor_txt:
            img = mapping.get(ch)
            if img:
                chars.append({"txt": ch, "img": img, "is_target": False})
        renpy.random.shuffle(chars)
        slots = kezi_slots()
        renpy.random.shuffle(slots)
        all_chars = []
        for i, c in enumerate(chars):
            c["pos"] = slots[i % len(slots)]
            all_chars.append(c)
        kezi_progress = 0
        kezi_finished = []
        kezi_target_count = len(kezi_seq)
    # ---------- 音效定义 ----------
    # 音效文件放在 game/audio_01/ 目录下（没有就新建 audio_01 文件夹），
    # 文件名前缀固定，扩展名任意（ogg / mp3 / wav 均可，按优先级自动识别）：
    #   carve    —— 点击字时模拟刻字的声效
    #   correct  —— 结算判定成功的音效
    #   pass     —— 点击"跳过"按钮的声效
    #   reshape  —— 点击"重置"按钮的声效
    #   wrong    —— 结算判定失败的音效
    # 若某个音效文件不存在，代码会自动跳过，不会报错。
    KEZI_SFX = {
        "carve":   ["audio_01/carve.ogg", "audio_01/carve.mp3", "audio_01/carve.wav"],
        "correct": ["audio_01/correct.ogg", "audio_01/correct.mp3", "audio_01/correct.wav"],
        "pass":    ["audio_01/pass.ogg", "audio_01/pass.mp3", "audio_01/pass.wav"],
        "reshape": ["audio_01/reshape.ogg", "audio_01/reshape.mp3", "audio_01/reshape.wav"],
        "wrong":   ["audio_01/wrong.ogg", "audio_01/wrong.mp3", "audio_01/wrong.wav"],
    }
    def kezi_play_sound(name):
        """按优先级查找并播放指定音效；找不到文件时静默跳过"""
        for f in KEZI_SFX.get(name, []):
            if renpy.loadable(f):
                try:
                    renpy.sound.play(f)
                except Exception:
                    # 音频解码失败等情况静默跳过，绝不让点击报错
                    pass
                return
    # ---------- 手机端真机震动（移植 Android 后生效） ----------
    # 桌面端直接跳过；Android 端通过 pyjnius 调用系统震动服务。
    # 兼容新旧 Android API：API 31+ 走 VibratorManager，旧版本走 VIBRATOR_SERVICE。
    # ★ 打包 Android 时需要在 options.rpy 里声明震动权限：
    #   define build.android_permissions = ["VIBRATE"]
    def kezi_vibrate(ms=30):
        if not renpy.android():
            return
        try:
            from jnius import autoclass
            activity = autoclass("org.renpy.android.PythonActivity").mActivity
            Context = autoclass("android.content.Context")
            VibrationEffect = autoclass("android.os.VibrationEffect")
            try:
                # Android 12 (API 31) 及以上
                manager = activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE)
                vibrator = manager.getDefaultVibrator()
            except Exception:
                # 旧版 Android
                vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
            if vibrator is None:
                return
            effect = VibrationEffect.createOneShot(int(ms), VibrationEffect.DEFAULT_AMPLITUDE)
            vibrator.vibrate(effect)
        except Exception:
            # 任何异常都静默忽略，不影响游戏运行
            pass
    # ---------- 点击校验 ----------
    def kezi_click(item):
        """点击任何未刻的字（无论正确/错误、顺序对错）都刻上、锁定并累计进度；
        正误判定留到进度集满后的结算界面统一呈现"""
        global kezi_progress, kezi_finished
        if item in kezi_finished:
            return
        if kezi_progress >= len(kezi_seq):
            # 已集满 8 字，进入结算阶段，忽略后续点击
            return
        # 不管是铭文字还是干扰字，点一下就刻上、进度 +1
        kezi_finished.append(item)
        kezi_progress += 1
        # 点击反馈：仅手机端真机轻微震动；桌面端无震动反馈（只有音效）
        # try/except 包裹：任何反馈失效都不会让点击弹错误框
        try:
            kezi_vibrate(30)
        except Exception:
            pass
        # 音效：普通点击播放刻字声；刻下最后一笔时按判定结果播放成功/失败音效
        if kezi_progress >= len(kezi_seq):
            if kezi_correct_count() >= len(kezi_seq):
                kezi_play_sound("correct")
            else:
                kezi_play_sound("wrong")
        else:
            kezi_play_sound("carve")
        # 后续追加：刻痕视觉特效
        renpy.restart_interaction()
    # ---------- 结算：统计按序正确的字数 ----------
    def kezi_correct_count():
        """按点击顺序逐一对照『受命于天，既寿永昌』，位置正确记 1"""
        n = 0
        for i, item in enumerate(kezi_finished):
            if i < len(kezi_seq) and item["txt"] == kezi_seq[i]:
                n += 1
        return n
    # ---------- 重置 ----------
    def kezi_reset():
        """清空进度、重新打乱小篆位置，从头开始"""
        kezi_build()
        renpy.restart_interaction()
# ---------- 存档变量（default 保证读档 / 重复进入安全） ----------
default kezi_progress = 0
default kezi_finished = []
default all_chars = []
default kezi_seq = []          # 实际参与游戏的正确字序列（按顺序）
default kezi_missing = []      # 没有匹配到图片的字（用于界面提示）
default kezi_target_count = 0  # 本关需要刻的字总数
default kezi_intro_done = False  # 开场对话只播一次，重玩不再重复
# ---------- 入口（Ren'Py 强制要求，勿删） ----------
label start:
    # 片头标题界面（只在整局游戏最开始出现一次）
    scene black
    with fade
    # 全篇统一的舒缓配乐（片头即响起）
    play music "audio/common/calm.ogg" fadein 2.0 loop
    call screen title_card

    # 第一章开场视频（videos/ch01.webm，可暂停 / 倍速 / 跳过）
    call play_chapter_movie(1)
    # 播放视频时音乐会淡出，播完立刻接回同一首配乐
    play music "audio/common/calm.ogg" fadein 2.0 loop

    # 开场：烛火下的蓝田玉，玉玺第一视角叙事
    scene expression KEZI_BG with dissolve
    if not kezi_intro_done:
        call screen chapter_intro(
            "刻  玺",
            "公元前 221 年　・　咸阳宫",
            [
                "我是一块蓝田玉。",
                "在被人从山里凿出来之前，我在黑暗里躺了不知多少年。",
            ],
            [
                "按顺序点出「受命于天，既寿永昌」。",
                "点错顺序也无妨——只是刻痕会被磨平，从头再刻一遍。",
            ],
        )
        call screen kezi_dialog("我是一方玉玺，蓝田玉的身子，在黑暗里躺了不知多少年。")
        call screen kezi_dialog("今日，内侍将我捧上御案。烛火照在我温润的身体上，也照亮了案旁那支细细的刻刀。")
        call screen kezi_dialog("持刀的人叫李斯。他俯下身，指腹缓缓抚过我的印面，低声说：")
        call screen kezi_dialog("“吾为陛下刻八字铭文，昭告天下。”")
        call screen kezi_dialog("刀锋落下之前，请帮我记住这八个字的位置——")
        call screen kezi_dialog("受命于天，既寿永昌。刻对了，我便是传国重器；刻错了……我们，就得重来。")
        $ kezi_intro_done = True
    jump kezi_minigame
# ---------- 刻字小游戏主流程 ----------
label kezi_minigame:
    $ kezi_build()
    # 背景音乐：与全篇统一的舒缓配乐（同一首曲子循环）
    if renpy.loadable("audio/common/calm.ogg"):
        $ renpy.music.play("audio/common/calm.ogg", fadein=1.5, loop=True)
    call screen kezi_game
    $ result = _return
    if result == "win":
        jump kezi_win
    elif result == "skip":
        jump kezi_skip
    # 兜底：非预期返回值时重新进入
    jump kezi_minigame
# ---------- 通关（结算：正确/错误在此时才呈现，随后过渡对话收尾） ----------
label kezi_win:
    # 刻字结束，背景音乐淡出后接回全篇统一配乐
    if renpy.loadable("audio/common/calm.ogg"):
        $ renpy.music.stop(fadeout=1.5)
        $ renpy.music.play("audio/common/calm.ogg", fadein=2.0, loop=True)
    scene expression KEZI_BG with dissolve
    $ correct_n = kezi_correct_count()
    if correct_n >= len(kezi_seq):
        # 全部按序正确
        call screen kezi_dialog("八个字在蓝田玉上依次成形——受命于天，既寿永昌。")
        call screen kezi_dialog("四方的刻痕严丝合缝，仿佛我生来就该有它们。")
        call screen kezi_dialog("李斯吹去玉屑，久久注视着我：“此玺一成，天下皆知陛下受命于天。”")
        call screen kezi_dialog("从此，我不再只是一块美玉。我是传国玉玺。")
        # ★ 已接入主线：刻对八字后进入第二章（太后攥玺）
        jump game_02_entry
    else:
        # 有错序：结算台词 + 过渡对话
        # 注意：call screen 的参数是普通 Python 表达式，字符串里的 [变量]
        # 不会像 say 语句那样自动插值，必须先拼接好再传入，否则会原样显示
        $ wrong_line = "（本次按序正确 {}/{}。）".format(correct_n, kezi_target_count)
        call screen kezi_dialog("刻完了……但有几处刻痕的位置似乎不太对。")
        call screen kezi_dialog(wrong_line)
        call screen kezi_dialog("李斯皱了皱眉，指尖抚过歪斜的刻痕：“不妥。重刻。”")
        call screen kezi_dialog("于是刻痕被一点点磨平，我重回空白，等待刀锋再次落下。")
    # 有错序：回到小游戏重刻
    jump kezi_minigame
# ---------- 跳过 ----------
label kezi_skip:
    # 刻字结束，背景音乐淡出后接回全篇统一配乐
    if renpy.loadable("audio/common/calm.ogg"):
        $ renpy.music.stop(fadeout=1.5)
        $ renpy.music.play("audio/common/calm.ogg", fadein=2.0, loop=True)
    scene expression KEZI_BG with dissolve
    call screen kezi_dialog("（你放下了刻刀，暂且跳过了这一段。）")
    call screen kezi_dialog("刻刀悬在半空，终究没有落下。")
    call screen kezi_dialog("李斯搁刀长叹：“今日玉性未定，不宜动刀。改日再刻吧。”")
    # ----- 跳过后不回到游戏界面，直接继续推进故事 -----
    call screen kezi_dialog("数日后，李斯终究还是亲手执刀，在我身上刻下了那八个字。")
    call screen kezi_dialog("受命于天，既寿永昌。我成为了大秦的传国玉玺。")
    call screen kezi_dialog("此后许多年，我辗转于群雄之手，见证了王朝的兴衰更迭。")
    call screen kezi_dialog("故事，才刚刚开始。")
    # ★ 已接入主线：进入第二章（太后攥玺）
    jump game_02_entry
# ---------- 跳过后的故事过渡（占位：正式接入主线时替换本 label） ----------
label kezi_story_continue:
    scene expression KEZI_BG with dissolve
    call screen kezi_dialog("（本章完。主线剧情制作中……）")
    # return 会结束本关、回到主菜单；
    # 接入主线后可删除本 label，直接从 kezi_skip 的结尾 jump 到主线
    return


# ============================================================
# 第二部分：界面（原 screens.rpy）
# ============================================================
# ---------- 台词对话框：大字体 + 前方留空隙，点击任意处继续 ----------
screen kezi_dialog(txt):
    modal True
    zorder 300
    # 点击屏幕任意位置继续（放在最底层）
    button:
        xfill True
        yfill True
        background None
        action Return()
    # 底部对话框
    frame:
        xalign 0.5
        yalign 0.92
        xmaximum 1640
        background "#0d0a07e6"
        # 前方（左侧）留出空隙
        padding (70, 36)
        vbox:
            spacing 10
            text "[txt]":
                font KEZI_FONT
                size 48
                color "#e8d5a3"
            text "（点击任意处继续）":
                font KEZI_FONT
                size 22
                color "#8f7f5e"
# ---------- 悬浮提示框：鼠标悬浮小篆时弹出对应简体中文 ----------
screen kezi_tip(txt, tx, ty):
    zorder 200
    frame:
        xpos tx
        xanchor 0.5
        ypos (ty - 110)
        background "#0d0a07e6"
        padding (30, 12)
        text "[txt]":
            font KEZI_FONT
            size 46
            color "#ffe9b0"
# ---------- 刻字游戏主界面 ----------
screen kezi_game():
    # 背景：和田玉
    add KEZI_BG
    # ---------- 顶部：目标铭文 ----------
    frame:
        xalign 0.5
        ypos 28
        background "#0d0a07b8"
        padding (60, 20)
        text "受命于天，既寿永昌":
            font KEZI_FONT
            size 64
            color "#e8d5a3"
    # ---------- 进度显示（已刻字数 + 已刻内容） ----------
    $ carved_txt = "".join([c["txt"] for c in kezi_finished])
    text "已刻：[kezi_progress]/[kezi_target_count]    [carved_txt]":
        font KEZI_FONT
        size 38
        color "#cbb98f"
        xalign 0.5
        ypos 136
    # ---------- 右上角：重置 / 跳过按钮 ----------
    hbox:
        xalign 0.985
        ypos 32
        spacing 26
        textbutton "重 置":
            action [Hide("kezi_tip"), Function(kezi_play_sound, "reshape"), Function(kezi_reset)]
            text_font KEZI_FONT
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            background "#3a2e20c8"
            hover_background "#5a4630e0"
            padding (34, 14)
        textbutton "跳 过":
            action [Hide("kezi_tip"), Function(kezi_play_sound, "pass"), Return("skip")]
            text_font KEZI_FONT
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            background "#3a2e20c8"
            hover_background "#5a4630e0"
            padding (34, 14)
    # ---------- 小篆字散布区 ----------
    for item in all_chars:
        if item in kezi_finished:
            # 已刻好的字：变暗锁定，不可再点击
            add item["img"]:
                at Transform(zoom=KEZI_CHAR_ZOOM)
                pos item["pos"]
                xanchor 0.5
                yanchor 0.5
                alpha 0.55
        else:
            # 未刻的字：可点击（点错静默忽略，无任何提示）
            # 注意：idle 与 hover 用同一张图，不做悬浮放大，避免任何缩放动效
            imagebutton:
                at Transform(zoom=KEZI_CHAR_ZOOM)
                idle item["img"]
                hover item["img"]
                pos item["pos"]
                xanchor 0.5
                yanchor 0.5
                hovered Show("kezi_tip", txt=item["txt"], tx=item["pos"][0], ty=item["pos"][1])
                unhovered Hide("kezi_tip")
                action Function(kezi_click, item)
                # 后续追加：点对时播放刻字音效、刻痕视觉特效
    # ---------- 素材提示：一张图都没找到 ----------
    if not all_chars:
        frame:
            xalign 0.5
            yalign 0.5
            background "#0d0a07e6"
            padding (50, 30)
            text "未找到小篆图片，请检查 game/images_01/seal_chars/ 目录。":
                font KEZI_FONT
                size 36
                color "#ff9a7a"
                text_align 0.5
    # ---------- 素材提示：部分字没匹配到图片（建议检查文件名） ----------
    if kezi_missing:
        $ missing_txt = "、".join(kezi_missing)
        text "提示：以下字未匹配到图片：[missing_txt]":
            font KEZI_FONT
            size 22
            color "#ff9a7a"
            xalign 0.5
            ypos 1035
            text_align 0.5
    # ---------- 结算界面：进度集满后统一呈现正确/错误 ----------
    if kezi_target_count > 0 and kezi_progress >= len(kezi_seq):
        $ _ok_n = kezi_correct_count()
        frame:
            xalign 0.5
            yalign 0.42
            background "#0d0a07e6"
            padding (70, 42)
            vbox:
                spacing 26
                text "刻字完成！":
                    font KEZI_FONT
                    size 72
                    color "#ffe9b0"
                    xalign 0.5
                # 按点击顺序逐字呈现：金色＝该位置正确，暗红＝该位置错误
                hbox:
                    spacing 20
                    xalign 0.5
                    for i, item in enumerate(kezi_finished):
                        $ _ok = (i < len(kezi_seq) and item["txt"] == kezi_seq[i])
                        if _ok:
                            text item["txt"]:
                                font KEZI_FONT
                                size 56
                                color "#ffd97a"
                        else:
                            text item["txt"]:
                                font KEZI_FONT
                                size 56
                                color "#b0604c"
                text "按序正确：[_ok_n]/[kezi_target_count]    （金色＝位置正确    暗红＝位置错误）":
                    font KEZI_FONT
                    size 26
                    color "#cbb98f"
                    xalign 0.5
                # 后续追加：通关震动反馈
                textbutton "继 续":
                    action [Hide("kezi_tip"), Return("win")]
                    text_font KEZI_FONT
                    text_size 34
                    text_color "#e8d5a3"
                    text_hover_color "#ffffff"
                    background "#3a2e20c8"
                    hover_background "#5a4630e0"
                    padding (34, 14)
                    xalign 0.5
