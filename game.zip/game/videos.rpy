# ==========================================
# 章节开场视频（带 暂停 / 倍速 / 跳过）
# ==========================================
# 视频放在 game/videos/ 目录下，格式为 WebM（VP9 视频 + Opus 音频）。
# Ren'Py 不支持 MP4/H.264/HEVC/AAC，所以原始 mp4 已经转码成 webm。
#
# 视频与章节的对应关系（按时间线顺序）：
#   ch01 → 第一章「刻 玺」(game_01.rpy  label start)
#   ch02 → 第二章「掷 玺」(game_02.rpy  label game_02_entry)
#   ch03 → 第三章「井 底」(game_03.rpy  label game_03_entry)
#   ch04 → 第四章「引火求援」(game_04.rpy  label game_04_entry)
#   ch05 → 第五章「千年流转」(game_05.rpy  label game_06)
#
# 关于倍速：
#   Ren'Py 的播放器（libav）没有变速接口，也不支持中途 seek，
#   所以倍速靠"预渲染"实现——每个视频都有三份：
#       ch0X.webm       1.0 倍速
#       ch0X_x15.webm   1.5 倍速
#       ch0X_x2.webm    2.0 倍速
#   切换倍速时会把当前视频从头重播（显示提示），这是唯一可行的做法。
#
# 想换视频：把新文件转成 webm 后覆盖同名文件即可（三份都要换）；
# 若时长变化，同步改下面 CHAPTER_MOVIE 里的秒数（自动结束靠它计时）。

define CHAPTER_MOVIE = {
    1: ("movie_ch01", 24.4),
    2: ("movie_ch02", 14.8),
    3: ("movie_ch03", 10.0),
    4: ("movie_ch04", 68.0),
    5: ("movie_ch05", 27.3),
}

# 三档倍速 -> 文件名后缀
define MOVIE_SPEED_LIST = [("1.0", ""), ("1.5", "_x15"), ("2.0", "_x2")]

# 让所有影片都用固定的 "movie" 频道（Ren'Py 默认会为每个 Movie 动态分配
# _movie_1 / _movie_2…，那样就没法统一暂停了）
define config.auto_movie_channel = False

init python:
    # Movie 显示对象必须在 init 阶段创建，所以统一在这里注册成图像。
    # loop=False：播完停在最后一帧，由计时器负责推进剧情。
    for _n in range(1, 6):
        for _sp, _suf in MOVIE_SPEED_LIST:
            _img = "movie_ch%02d%s" % (_n, _suf)
            renpy.image(_img, Movie(
                play="videos/ch%02d%s.webm" % (_n, _suf),
                size=(config.screen_width, config.screen_height),
                loop=False,
            ))

    MOVIE_SPEED_SUFFIX = dict(MOVIE_SPEED_LIST)
    MOVIE_SPEED_CYCLE = {"1.0": "1.5", "1.5": "2.0", "2.0": "1.0"}

    def movie_set_pause(paused):
        """暂停 / 继续播放（视频画面会随之定格在场频道上）"""
        try:
            renpy.music.set_pause(paused, channel="movie")
        except Exception:
            pass

    def movie_speed_hint(sp):
        renpy.notify("%s 倍速（从头播放）" % sp)

    def movie_resume_hint():
        # Ren'Py 播放器不支持断点续播，继续时画面会从头开始，这里明确告知
        renpy.notify("播放器不支持断点续播，视频已从头播放")


default _movie_img = "movie_ch01"
default _movie_len = 1.0


# 全屏播放 + 左上角 暂停/倍速 + 右下角 跳过
screen chapter_movie(base, length):

    modal True
    zorder 200

    default speed = "1.0"
    default paused = False
    default played = 0.0

    # 当前倍速对应的视频
    $ _img = base + MOVIE_SPEED_SUFFIX[speed]

    add _img:
        xalign 0.5
        yalign 0.5

    # 播放计时：暂停时不累加；累加值按倍速走，与视频实际时长对齐
    timer 0.05 repeat True action If(
        not paused,
        SetScreenVariable("played", played + 0.05 * float(speed)),
        NullAction()
    )

    # 到点自动继续
    timer 0.05 repeat True action If(played >= length, Return("end"), NullAction())

    # ---------- 左上角：暂停 / 倍速 ----------
    # 放左上角是为了避开底部画面里的字幕与人脸，手机上也不会挡住手势区
    hbox:
        xalign 0.015
        yalign 0.045
        spacing 22

        textbutton ("继 续" if paused else "暂 停"):
            style "game_button"
            text_size 30
            action If(
                paused,
                [
                    SetScreenVariable("paused", False),
                    Function(movie_set_pause, False),
                    SetScreenVariable("played", 0.0),
                    Function(movie_resume_hint),
                ],
                [
                    SetScreenVariable("paused", True),
                    Function(movie_set_pause, True),
                ],
            )

        textbutton "倍速 %s×" % speed:
            style "game_button"
            text_size 30
            action [
                Function(movie_set_pause, False),
                SetScreenVariable("paused", False),
                SetScreenVariable("speed", MOVIE_SPEED_CYCLE[speed]),
                SetScreenVariable("played", 0.0),
                Function(movie_speed_hint, MOVIE_SPEED_CYCLE[speed]),
            ]

    # 暂停时给个明显提示，避免误以为卡死
    if paused:
        text "已暂停":
            xalign 0.5
            yalign 0.5
            font STORY_FONT
            size 56
            color "#e8d5a3"
            outlines [(3, "#1a1208", 0, 0)]
            at story_blink

    # ---------- 右下角：跳过 ----------
    # 注意：不要用 ▶ 这类符号，macOS 会回退到彩色 emoji 字体，颜色不受控
    textbutton "跳过剧情  >>":
        style "game_button"
        xalign 0.985
        yalign 0.955
        text_size 30
        action [
            Function(movie_set_pause, False),
            Return("skip"),
        ]

    # 键盘：空格暂停、Esc 跳过
    key "K_SPACE" action If(
        paused,
        [
            SetScreenVariable("paused", False),
            Function(movie_set_pause, False),
            SetScreenVariable("played", 0.0),
            Function(movie_resume_hint),
        ],
        [
            SetScreenVariable("paused", True),
            Function(movie_set_pause, True),
        ],
    )
    key "K_ESCAPE" action [
        Function(movie_set_pause, False),
        Return("skip"),
    ]


# 用法：call play_chapter_movie(1)    —— 播放第一章开场视频
label play_chapter_movie(n):
    # 播放期间禁掉回滚，避免玩家退回视频里反复触发
    $ renpy.block_rollback()
    $ _movie_img, _movie_len = CHAPTER_MOVIE[n]

    # 播放期间隐藏底部「回退/历史/快进」快捷菜单，画面更干净
    $ quick_menu = False

    stop music fadeout 0.4
    window hide
    scene black

    call screen chapter_movie(_movie_img, _movie_len)
    $ _movie_skipped = (_return == "skip")
    $ movie_set_pause(False)

    $ quick_menu = True
    scene black with dissolve
    return
