# ========== 第二章：掷玺（挣脱小游戏） ==========
# 公元 9 年，长乐宫。王莽篡汉，遣使索玺，太后怒而掷玺，崩其一角。
default zheng_ka = 0
default shake_x = 0
default shake_timer = 0

init python:
    # 挣扎过程中的"触动"：每扭动一次换一句（玉玺第一视角）
    TUO_DONG = [
        "（左右扭动身体，试着从她的指缝间滑出去。）",
        "她的掌心有沉水香的味道。",
        "她在发抖。攥着我的这只手，比我还怕。",
        "殿外有人压着嗓子喊：“安汉公到——”",
        "她把脸贴在我身上，像抱住汉家最后一块骨头。",
        "我忽然有些不忍心再挣了。",
    ]

    def tuo_dong_line():
        return TUO_DONG[min(zheng_ka, len(TUO_DONG) - 1)]

    # 手机端震动反馈：安卓走 Ren'Py 自带的 vibrate，iOS 用系统「轻点」触感兜底。
    # 桌面端（PC/Mac）没有任何可震动的硬件，函数会静默什么都不做。
    def tuo_vibrate(strength=0.06):
        try:
            renpy.vibrate(strength)
        except Exception:
            pass

        if getattr(renpy, "ios", False):
            try:
                import ctypes
                _at = ctypes.CDLL(
                    "/System/Library/Frameworks/AudioToolbox.framework/AudioToolbox"
                )
                # 1519 = 系统「Peek」轻触感（iOS 10+，仅带 Taptic Engine 的机型有反馈）
                _at.AudioServicesPlaySystemSound(ctypes.c_uint32(1519))
            except Exception:
                pass

screen tuoli_minigame():
    modal True
    zorder 100

    add "images/game_02/bg_empress.png" xysize (config.screen_width, config.screen_height)
    add "images/game_02/yuxi_normal.png" zoom 1.2 xalign 0.5 yalign 1 xoffset shake_x

    text "她的五指收得很紧，指节都白了。":
        xalign 0.5
        yalign 0.05
        size 44
        color "#e8d5a3"
        outlines [(2, "#000000", 0, 0)]

    # 扭动一次，换一句心事（加一层深色底衬，压在玉玺上也看得清）
    frame:
        xalign 0.5
        yalign 0.70
        background "#0d0a07cc"
        padding (46, 16)
        text TUO_DONG[min(zheng_ka, len(TUO_DONG) - 1)]:
            size 40
            color "#FFE9B0"
            text_align 0.5

    textbutton "← 向左扭动身体":
        style "game_button"
        xalign 0.2
        yalign 0.85
        xsize 330
        ysize 82
        text_size 34
        text_color "#e8d5a3"
        text_hover_color "#ffffff"
        action [
            Function(tuo_vibrate, 0.07),
            Play("sound", "audio/game_02/struggle.wav"),
            SetVariable("zheng_ka", zheng_ka + 1),
            SetVariable("shake_timer", 4),
            If(zheng_ka >= 5, [Stop("sound"), Function(tuo_vibrate, 0.35), Return("成功")], NullAction())
        ]

    textbutton "向右扭动身体 →":
        style "game_button"
        xalign 0.8
        yalign 0.85
        xsize 330
        ysize 82
        text_size 34
        text_color "#e8d5a3"
        text_hover_color "#ffffff"
        action [
            Function(tuo_vibrate, 0.07),
            Play("sound", "audio/game_02/struggle.wav"),
            SetVariable("zheng_ka", zheng_ka + 1),
            SetVariable("shake_timer", 4),
            If(zheng_ka >= 5, [Stop("sound"), Function(tuo_vibrate, 0.35), Return("成功")], NullAction())
        ]

    textbutton "不再挣扎":
        style "game_button"
        xalign 0.5
        yalign 0.95
        xsize 260
        ysize 78
        text_size 34
        text_color "#cbb98f"
        text_hover_color "#ffffff"
        action [Stop("sound"), Return("失败")]

    timer 0.05 repeat True action If(
        shake_timer > 0,
        [
            SetVariable("shake_timer", shake_timer - 1),
            SetVariable("shake_x", renpy.random.randint(-15, 15))
        ],
        SetVariable("shake_x", 0)
    )

label game_02_entry:
    # 第二章开场视频（videos/ch02.webm，可暂停 / 倍速 / 跳过）
    call play_chapter_movie(2)
    # 视频期间音乐淡出，播完接回全篇统一配乐
    play music "audio/common/calm.ogg" fadein 2.0 loop
    $ zheng_ka = 0
    $ shake_x = 0
    $ shake_timer = 0

    scene expression Transform("images/game_02/bg_empress.png", xysize=(config.screen_width, config.screen_height))
    with fade

    call screen chapter_intro(
        "掷  玺",
        "公元 9 年　・　长乐宫",
        [
            "王莽要篡汉了。他派来的使者，就跪在阶下等着。",
            "太后把我攥在手里——她不是舍不得我，她是舍不得汉家。",
        ],
        [
            "点击「向左 / 向右扭动身体」，连挣五次便能脱身。",
            "也可以选「不再挣扎」。有些东西，挣开了反而更疼。",
        ],
    )

    "她的掌心是温的，指尖却是凉的。"
    "我贴着她的腕子，能摸到脉搏一下一下撞着我的边沿。"
    "殿外，那个叫王莽的人，已经等得不耐烦了。"

    call screen tuoli_minigame
    $ jieguo = _return
    stop sound

    scene expression Transform("images/game_02/bg_empress.png", xysize=(config.screen_width, config.screen_height))
    with dissolve

    if jieguo == "成功":
        "我拼尽全力一挣，从她指缝间滑了出去——"
        "她慌了，伸手来捞。"
    else:
        "我没有再挣。她的手指像铁箍，收得更紧。"
        "然后，她站了起来。"

    "下一瞬，我被高高举起，狠狠砸向殿柱。"

    play sound "audio/game_02/crash.wav"

    # 玉玺崩角特写：原图 7992x4492（超出本机 4096 纹理上限），先缩到 900x506 再显示；
    # 必须用 as 指定图像标签，否则 show expression 在部分版本下不会真正显示
    show expression Transform("images/game_02/yuxi_crack.png", xysize=(900, 506)) as yuxi_crack_img:
        xalign 0.5
        yalign 0.42
    with dissolve

    "一声脆响。"
    "我的边角，崩掉了一块。"

    "太后指着我，声音抖得不成样子："
    "“我年纪大了，迟早要死；可你们这帮兄弟，将来一定会被灭族！！”"

    "后来，王莽命人用黄金替我把那一角镶上。世人称之为“金镶玉”。"
    "都说那是天下最贵的一角金子。"
    "只有我知道，它补的不是石头，是一个王朝最后一点硬气。"

    # ★ 已接入主线：进入第三章（井底）
    jump game_03_entry
