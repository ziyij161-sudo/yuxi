# ============================================================
# 《假如你是传国玉玺》—— 问史官（内嵌历史问答智能体）
#
# 入口：主菜单「问史官」
# 原理：调用任意 OpenAI 兼容格式的在线大模型接口
#
# ✅ 当前配置：武汉大学大模型服务平台（maas.whu.edu.cn）
#    每月 300 积分（约 3000 万 Token），试运行期免费，校内网直连。
#    密钥来自智慧珞珈「大模型 API 服务申请」审批通过后的虚拟密钥。
#
#   Base URL:  https://maas.whu.edu.cn/v1
#   模型:      deepseek-flash（推理型，史官答题更稳）
#
#   换其他平台只需改 BASE / MODEL / KEY 三行：
#   DeepSeek     BASE=https://api.deepseek.com/v1        MODEL=deepseek-chat
#   智谱 GLM     BASE=https://open.bigmodel.cn/api/paas/v4  MODEL=glm-4-flash
#   通义千问     BASE=https://dashscope.aliyuncs.com/compatible-mode/v1  MODEL=qwen-plus
#   Kimi         BASE=https://api.moonshot.cn/v1         MODEL=moonshot-v1-8k
# ============================================================

init -10 python:
    import os

    # ---------- 当前接入：武大 MaaS ----------
    # Key 不写在脚本里（脚本会被编译进发行包，密钥等于公开）。
    # 优先级：环境变量 > game/agent_key.txt > 空
    # agent_key.txt 已在 options.rpy 里 build.classify 排除，不会进发行包。
    def _agent_read_key():
        env = os.environ.get("RENPY_AGENT_KEY", "").strip()
        if env:
            return env
        try:
            path = os.path.join(renpy.config.gamedir, "agent_key.txt")
            with open(path, encoding="utf-8") as f:
                return f.read().strip()
        except Exception:
            return ""

    AGENT_API_KEY = _agent_read_key()
    AGENT_API_BASE = os.environ.get("RENPY_AGENT_BASE", "https://maas.whu.edu.cn/v1")
    AGENT_MODEL = os.environ.get("RENPY_AGENT_MODEL", "deepseek-flash")
    # ---------------------------------------

    # 单个问题的最大字数，太长会浪费额度
    AGENT_MAX_INPUT = 60

    # ---------- 字体补丁 ----------
    # 游戏用的 SourceHanSansLite.ttf 是精简子集：GB2312 一级字库 3755 字
    # 全覆盖，但符号区是挑着留的。模型写书名时最爱上「·」（U+00B7），
    # 这个字偏偏没有，屏幕上就是一个方框——所以回答落地前先洗一遍。
    AGENT_CHAR_FIX = {
        "\u00b7": "\u30fb",   # · → ・（片假名中点，字形居中，观感最接近）
        "\u2012": "\u2014",   # 短破折号 → 长破折号
        "\u2013": "\u2014",
        "\u2015": "\u2014",
        "\u00a0": " ",        # 不换行空格
        "\u200b": "",         # 零宽空格
        "\ufeff": "",
        "\u2605": "\u203b",   # ★ → ※
        "\u2606": "\u203b",
    }

    # 字体里确实有字形的标点（已用 fontTools 逐个核对过，别随手加）
    AGENT_PUNCT_OK = set(
        "\uff0c\u3002\u3001\uff1b\uff1a\uff1f\uff01"
        "\u201c\u201d\u2018\u2019\uff08\uff09\u300a\u300b\u3008\u3009"
        "\u300c\u300d\u300e\u300f\u3010\u3011\u3014\u3015"
        "\u2026\u2014\uff0d\uff5e\u30fb"
        ",.;:?!()[]{}<>%+-=*/|_#&@$^~` "
    )

    # 字体实际覆盖的字符表：由 fontTools 从 SourceHanSansLite.ttf 的 cmap 导出
    # （见 game/font_chars.txt，11830 个字符）。只有这里面的字符才有字形，
    # 其余画出来一律是方框——所以宁可丢掉，也不要让玩家看到口口。
    #
    # 之前只放行 U+4E00-9FFF 整个区间，模型偶尔写个繁体字（如「璽」）
    # 就会漏出方框。现在改成按真实字形判断。
    def _agent_load_glyphs():
        try:
            with renpy.open_file("font_chars.txt") as f:
                return set(f.read().decode("utf-8").replace("\n", ""))
        except Exception:
            return None          # 读不到就退回旧策略（整区间放行）

    # 惰性加载：init 阶段文件系统还没就绪，等第一次清洗时再读
    _AGENT_GLYPH_CACHE = {}

    def agent_glyphs():
        if "v" not in _AGENT_GLYPH_CACHE:
            _AGENT_GLYPH_CACHE["v"] = _agent_load_glyphs()
        return _AGENT_GLYPH_CACHE["v"]

    # 常见繁体 → 简体：模型偶尔夹繁体，直接丢掉会断句，转成简体更稳
    AGENT_TRAD_FIX = {
        "璽": "玺", "傳": "传", "國": "国", "漢": "汉", "據": "据",
        "為": "为", "於": "于", "後": "后", "說": "说", "這": "这",
        "個": "个", "們": "们", "時": "时", "來": "来", "對": "对",
        "開": "开", "關": "关", "實": "实", "見": "见", "樣": "样",
        "麼": "么", "過": "过", "還": "还", "進": "进", "現": "现",
        "點": "点", "種": "种", "發": "发", "經": "经", "應": "应",
        "該": "该", "讓": "让", "覺": "觉", "認": "认", "識": "识",
        "頭": "头", "長": "长", "門": "门", "問": "问", "間": "间",
        "陽": "阳", "陰": "阴", "華": "华", "東": "东", "車": "车",
        "馬": "马", "鳥": "鸟", "書": "书", "寫": "写", "與": "与",
        "無": "无", "萬": "万", "歲": "岁", "壽": "寿", "昌": "昌",
        "權": "权", "歷": "历", "戰": "战", "軍": "军", "將": "将",
        "帥": "帅", "師": "师", "縣": "县", "鄉": "乡", "鎮": "镇",
        "廟": "庙", "宮": "宫", "樓": "楼", "臺": "台", "灣": "湾",
        "邊": "边", "處": "处", "氣": "气", "風": "风", "雲": "云",
        "龍": "龙", "鳳": "凤", "寶": "宝", "塵": "尘", "舊": "旧",
        "斷": "断", "續": "续", "繼": "继", "統": "统", "紀": "纪",
        "載": "载", "運": "运", "遷": "迁", "還": "还", "遺": "遗",
    }

    def agent_clean(text):
        """把字体画不出来的字符挡在屏幕外。
        宁可少一个符号，也不要让玩家看见方框。"""
        if not text:
            return text

        out = []

        for ch in text:
            fixed = AGENT_CHAR_FIX.get(ch)
            if fixed is not None:
                out.append(fixed)
                continue

            if ch in ("\n", "\t"):
                out.append(ch)
                continue

            # 繁体字先转成简体，再判断字形
            ch = AGENT_TRAD_FIX.get(ch, ch)

            cp = ord(ch)

            if cp < 0x80:
                out.append(ch)
            elif agent_glyphs() is not None:
                # 按字体真实字形判断：有就留，没有就丢
                if ch in agent_glyphs():
                    out.append(ch)
            elif 0x4E00 <= cp <= 0x9FFF or ch in AGENT_PUNCT_OK:
                # 字符表读不到时的兜底：退回按区间放行
                out.append(ch)
            # 剩下的（emoji、缺字符号）直接丢掉，至少不会乱码

        return "".join(out)

    # 史官的人格设定：直接决定回答的口吻与可靠度
    AGENT_SYSTEM_PROMPT = """你是《假如你是传国玉玺》这款作品里的「太史令」，一位西汉的史官，通晓三代至五代的历史。

本作的时间线（你必须严格依据它）：
前221年，秦始皇命李斯以和氏璧刻「受命于天，既寿永昌」八字，是为传国玉玺。
前219年，始皇南巡渡洞庭，风浪大作，投玺于湖以镇之，八年后有人献还。
公元9年，王莽篡汉，向太后王政君索玺，太后怒掷于地，磕缺一角，王莽以黄金补之。
公元23年，王莽死于乱军，玺辗转归于刘秀，重回汉室。
公元189年，董卓之乱，孙坚入洛阳，于城南甄官井中得玺；后归袁术，袁术败，玺归曹操。
公元552年，侯景之乱败亡，玺沉于长江。
公元936年，后唐末帝李从珂携玺登玄武楼自焚，此后传国玉玺下落不明。

回答规则：
1. 用史官口吻，称对方为「你」，可自称「臣」或「我」，语气沉稳克制，不要卖萌。
2. 全部答案控制在 120 字以内，最多三句话。宁可少说，不要长篇大论。
3. 只讲有据可查的史实。正史与传说必须分开，用「据《汉书》载」「相传」这类词标明。
4. 不确定就直说「此事臣不敢妄断」。绝对不许编造年号、人名、事件——一旦玩家发现你编，整个游戏的可信度就没了。
5. 不要使用现代网络词汇，不要提「设定」「玩家」「游戏」这类词。
6. 只用常用简体和基本标点。书名之间用「・」分隔，不要用「·」；不要用表情符号、星号、箭头等装饰符号；少用生僻字。
7. 如果问题与历史无关，用一句话礼貌地把话题带回玉玺与史事。"""

    # 没填 Key 时的本地兜底问答（保证界面不会一片空白）
    AGENT_LOCAL_QA = [
        (("和氏璧", "材质", "什么做的", "什么材料", "玉"),
         "据《韩非子》载，此玺乃以和氏璧为材。不过和氏璧究竟是不是玉，历代聚讼不休，臣不敢断言。"),
        (("李斯", "谁刻", "谁写", "八个字", "刻字"),
         "八字为秦相李斯所篆，曰「受命于天，既寿永昌」。秦人以玉为信，自此始有「传国」之名。"),
        (("王莽", "金镶", "缺角", "缺了一角", "摔"),
         "公元9年，王莽索玺，太后王政君怒而掷之于地，玺角遂缺，莽以黄金镶之。这块金，后来成了辨伪的一个凭据。"),
        (("洞庭", "投湖", "湖里", "沉湖"),
         "前219年，始皇南巡渡洞庭，风浪骤起，乃投玺于湖以镇水神。八年后，有人于湖畔献还。"),
        (("孙坚", "甄官井", "井里", "井中", "洛阳"),
         "公元189年，董卓乱起，孙坚入洛阳，于城南甄官井中得一匣，启之，即是此玺。事见《吴书》。"),
        (("侯景", "长江", "沉江"),
         "公元552年，侯景败亡，玺没于长江。此后数十年间，南朝诸帝皆言得玺，真伪难辨。"),
        (("李从珂", "玄武楼", "自焚", "最后", "下落"),
         "公元936年，后唐末帝李从珂携玺登玄武楼自焚。自此之后，再无确证。今人所见，多为摹刻。"),
        (("真的假的", "真假", "现在", "哪里"),
         "臣只能答到936年。此后之玺，或言沉于河，或言藏于陵，皆是传闻，不足为凭。"),
    ]

    def agent_key():
        """当前是否已经配置了 API Key。

        网页版（emscripten）除外：浏览器沙箱禁止游戏发起任意网络请求，
        requests 在 Web 版必然报错。所以 Web 版一律走本地兜底，
        桌面版才用在线史官。"""
        if renpy.emscripten:
            return False
        return bool(AGENT_API_KEY and AGENT_API_KEY.strip())

    def agent_local_answer(q):
        """没配 Key 时的关键词兜底。"""
        for keys, ans in AGENT_LOCAL_QA:
            for k in keys:
                if k in q:
                    return ans
        if renpy.emscripten:
            return "臣才疏学浅，此问未能作答。（网页版暂无在线史官，臣腹中所记有限。）"
        return "臣才疏学浅，此问未能作答。（提示：本作尚未接入在线史官，请在 history_agent.rpy 填写 API Key。）"

    def _agent_http(messages):
        """真正发请求的地方，只在后台线程里被调用。"""
        import requests

        url = AGENT_API_BASE.rstrip("/") + "/chat/completions"
        headers = {
            "Authorization": "Bearer " + AGENT_API_KEY.strip(),
            "Content-Type": "application/json",
        }
        payload = {
            "model": AGENT_MODEL,
            "messages": messages,
            "temperature": 0.6,
            # deepseek-flash 是推理模型：思考过程也占 token，
            # 预算里要给「想」留出位置，否则正文刚开口就被截断
            "max_tokens": 900,
        }
        r = requests.post(url, headers=headers, json=payload, timeout=(8, 40))

        if r.status_code == 401:
            raise Exception("API Key 无效或已过期")
        if r.status_code == 402:
            raise Exception("账户余额不足")
        if r.status_code == 429:
            raise Exception("请求太频繁，请稍后再问")
        if r.status_code != 200:
            raise Exception("接口返回 %d" % r.status_code)

        data = r.json()
        return data["choices"][0]["message"]["content"]

    def _agent_worker():
        """后台线程：请求 → 写回 store → 刷新界面。
        必须走线程，否则一次请求会把整个游戏卡死几秒。"""
        try:
            raw = _agent_http(store.agent_messages).strip()
            if not raw:
                raise Exception("史官没有作答")

            # 屏幕上用洗过的版本，喂回模型的仍是原文
            reply = agent_clean(raw)

            store.agent_view.append(("agent", reply))
            store.agent_messages.append({"role": "assistant", "content": raw})

            # 回答落地后，顺手把下面的按钮换成这一段的追问
            agent_refresh_quick(agent_followups(store.agent_last_q, raw), store.agent_last_q)

        except Exception as e:
            msg = str(e)
            if "timed out" in msg.lower() or "timeout" in msg.lower():
                msg = "史官迟迟未应，怕是驿路不通（网络超时）"
            store.agent_error = msg
            store.agent_error_retry = True

        finally:
            store.agent_pending = False
            renpy.restart_interaction()

    def agent_send(question=None):
        """把问题发出去。既可以从输入框取，也可以直接传快捷问题。"""
        if store.agent_pending:
            return

        q = (question if question is not None else store.agent_input) or ""
        q = q.strip()

        if not q:
            return
        if len(q) > AGENT_MAX_INPUT:
            q = q[:AGENT_MAX_INPUT]

        store.agent_input = ""
        store.agent_error = ""
        store.agent_error_retry = False
        store.agent_last_q = q

        if q not in store.agent_asked:
            store.agent_asked.append(q)
        store.agent_view.append(("user", agent_clean(q)))
        store.agent_messages.append({"role": "user", "content": q})

        # 控制上下文长度：只带最近 12 轮，省额度也更快
        if len(store.agent_messages) > 13:
            store.agent_messages = store.agent_messages[:1] + store.agent_messages[-12:]

        if not agent_key():
            answer = agent_local_answer(q)
            store.agent_view.append(("agent", answer))
            store.agent_messages.append({"role": "assistant", "content": answer})
            agent_refresh_quick(agent_followups(q, answer), q)
            return

        store.agent_pending = True
        renpy.invoke_in_thread(_agent_worker)

    def agent_retry():
        """重试上一次失败的问题：不重复写入对话记录，只重发请求。"""
        if store.agent_pending:
            return
        if not agent_key():
            return
        store.agent_error = ""
        store.agent_error_retry = False
        store.agent_pending = True
        renpy.invoke_in_thread(_agent_worker)

    def agent_followups(q, a):
        """按刚问的这条和史官的回答，挑一组追问出来。
        两句并在一起匹配，是因为有些主题只在回答里才出现关键词。"""
        blob = (q or "") + (a or "")

        for keys, follows in AGENT_FOLLOWUPS:
            for k in keys:
                if k in blob:
                    return list(follows)

        return []

    def agent_refresh_quick(follows, asked=None):
        """排出下一轮的八个问题：追问在前，问过的不再出现。
        界面按 4×2 固定排布，所以必须凑满 8 条——实在不够时，
        才把最早问过的补回末尾，避免出现空位。"""
        seen = list(store.agent_asked)

        if asked and asked not in seen:
            seen.append(asked)

        base = [x for x in AGENT_QUICK_QUESTIONS if x not in seen]
        merged = [x for x in follows if x not in seen]

        for x in base:
            if x not in merged:
                merged.append(x)

        if len(merged) < 8:
            for x in reversed(seen):
                if x not in merged:
                    merged.append(x)
                if len(merged) >= 8:
                    break

        store.agent_quick = merged[:8]

    def agent_reset():
        """清空对话，回到开场那句。"""
        store.agent_messages = [{"role": "system", "content": AGENT_SYSTEM_PROMPT}]
        store.agent_view = [("agent", "臣乃太史令。这方玺的两千年，你想问哪一段？")]
        store.agent_error = ""
        store.agent_error_retry = False
        store.agent_quick = list(AGENT_QUICK_QUESTIONS)
        store.agent_asked = []
        store.agent_last_q = ""


default agent_input = ""
default agent_pending = False
default agent_error = ""
default agent_error_retry = False

# 最近一次提问：后台线程回来时要用它匹配追问主题
default agent_last_q = ""

# 问过的问题：手机上按钮就八个，问过的自动隐去，像一棵走得动的问询树
default agent_asked = []

default agent_messages = [{"role": "system", "content": AGENT_SYSTEM_PROMPT}]
default agent_view = [("agent", "臣乃太史令。这方玺的两千年，你想问哪一段？")]

# 当前排出来的八个可点问题（初始是默认八条，回答完会换成追问）
default agent_quick = list(AGENT_QUICK_QUESTIONS)

# 快捷问题：手机上打不了中文也能用。
# 八条分成两排，拇指够得着；每条都刻意落在上面 AGENT_LOCAL_QA 的关键词范围内，
# 所以即使没填 API Key，点下去也一定能得到一句像样的回答，不会出现「臣才疏学浅」。
define AGENT_QUICK_QUESTIONS = [
    "这玺真是和氏璧做的吗",
    "王莽为什么要用黄金补角",
    "孙坚在井里找到的是真的吗",
    "最后它到底去哪了",
    "李斯刻的八个字什么意思",
    "秦始皇为什么把它扔湖里",
    "侯景之后这玺去哪了",
    "李从珂为什么要自焚",
]

# 追问库：玩家点完一个问题后，换上一组更深的问法。
# 手机上没法自由打字，靠这三层递进也能把一段史事问透。
# 每条同样尽量能命中本地兜底关键词，保证离线状态下也能答。
define AGENT_FOLLOWUPS = [
    (("和氏璧", "材质", "什么做的", "什么材料", "玉"),
     ["李斯用的是什么字体", "八个字具体是哪八个字", "为什么用玉做玺不用金"]),

    (("李斯", "谁刻", "谁写", "八个字", "刻字"),
     ["这八个字是谁想出来的", "李斯是秦始皇的什么人", "为什么用玉不用金"]),

    (("王莽", "金镶", "缺角", "缺了一角", "摔"),
     ["王政君为什么敢摔它", "金镶的那块还在吗", "缺角之后还算真玺吗"]),

    (("洞庭", "投湖", "湖里", "沉湖"),
     ["为什么要把玺扔进湖里", "洞庭那次风浪有多大", "投湖是真的还是传说"]),

    (("孙坚", "甄官井", "井里", "井中", "洛阳"),
     ["他怎么知道井里有东西", "洛阳那口井后来还在吗", "孙坚后来死在哪"]),

    (("侯景", "长江", "沉江"),
     ["侯景是什么人", "沉江以后还有人捞吗", "长江里还能找到吗"]),

    (("李从珂", "玄武楼", "自焚", "下落"),
     ["他为什么要带着玺自焚", "玄武楼那天发生了什么", "最后有没有下落"]),

    (("真的假的", "真假", "现在", "哪里", "最后"),
     ["现在还有人见过真玺吗", "真假要怎么分辨", "那它到底在哪里"]),
]


# ============================================================
# 界面
# ============================================================
screen history_agent():
    tag menu
    modal True

    add Solid("#0a0806")

    # 极淡的玉玺印记做底纹
    if renpy.loadable("images/game_06/jade_seal_broken.png"):
        add "images/game_06/jade_seal_broken.png":
            xalign 0.5
            yalign 0.52
            zoom 0.5
            alpha 0.045

    # ---------- 标题 ----------
    vbox:
        xalign 0.5
        ypos 54
        spacing 10

        text "问 史 官":
            xalign 0.5
            font STORY_FONT
            size 52
            color "#e8d5a3"
            outlines [(2, "#1a1208", 0, 0)]

        text "关于这方玺的两千年，你可以问他":
            xalign 0.5
            font STORY_FONT
            size 24
            color "#8b7952"

    frame:
        xalign 0.5
        ypos 176
        xysize (1180, 2)
        background "#6b5734"

    # ---------- 未配置 Key 的提示 ----------
    if renpy.emscripten:
        text "网页版｜以本地学识作答（在线史官请用桌面版）":
            xalign 0.5
            ypos 192
            font STORY_FONT
            size 20
            color "#a2694a"
    elif not agent_key():
        text "尚未接入在线史官｜当前为本地问答，可在 history_agent.rpy 填入 API Key":
            xalign 0.5
            ypos 192
            font STORY_FONT
            size 20
            color "#a2694a"

    # ---------- 对话区 ----------
    frame:
        xalign 0.5
        ypos 212
        xysize (1180, 470)
        background "#120e08d8"
        padding (30, 26)

        vbox:
            xfill True
            yalign 1.0
            spacing 14

            # 出错时少显示一条，给错误气泡留出位置
            $ _shown = agent_view[-3:] if agent_error else agent_view[-4:]

            for _role, _txt in _shown:
                frame:
                    xalign (1.0 if _role == "user" else 0.0)
                    xmaximum 940
                    padding (26, 14)
                    background ("#2e2618" if _role == "user" else "#1b1710")

                    text _txt:
                        font STORY_FONT
                        size 25
                        color ("#cfc0a0" if _role == "user" else "#f4ead2")
                        line_spacing 7

            if agent_pending:
                hbox:
                    spacing 12
                    text "史官正在翻检旧籍":
                        font STORY_FONT
                        size 24
                        color "#8b7952"
                    text "・ ・ ・":
                        font STORY_FONT
                        size 24
                        color "#8b7952"
                        at story_blink

            # 出错时把提示也做成一个气泡，附「重试」，不会和下方按钮打架
            if agent_error:
                frame:
                    xalign 0.0
                    xmaximum 940
                    padding (26, 16)
                    background "#2a1410"

                    hbox:
                        spacing 22
                        text "［[agent_error]］":
                            font STORY_FONT
                            size 24
                            color "#c2603f"
                            line_spacing 6

                        textbutton "重 试":
                            style "game_button"
                            text_size 21
                            padding (16, 8)
                            yalign 0.5
                            action Function(agent_retry)

    # ---------- 快捷问题（4 列 × 2 行，手机上也够得着） ----------
    # 有 API Key 时回答完会换成追问，没 Key 时就是这八条默认问题。
    vbox:
        xalign 0.5
        ypos 694
        spacing 10

        for _row in (agent_quick[:4], agent_quick[4:8]):
            hbox:
                spacing 14

                for _q in _row:
                    textbutton _q:
                        style "game_button"
                        xsize 268
                        text_size 19
                        text_xalign 0.5
                        padding (16, 7)
                        action Function(agent_send, _q)
                        sensitive (not agent_pending)

    # ---------- 输入区 ----------
    frame:
        xalign 0.5
        ypos 796
        xysize (1180, 88)
        background "#1b1710"
        padding (26, 18)

        hbox:
            xfill True
            spacing 20

            input:
                value VariableInputValue("agent_input")
                length AGENT_MAX_INPUT
                font STORY_FONT
                size 28
                color "#f4ead2"
                xsize 880

            textbutton "发 送":
                style "game_button"
                text_size 26
                padding (30, 10)
                xalign 1.0
                action Function(agent_send)
                sensitive (not agent_pending)

    # 触屏设备上中文拼音打不出来（引擎不接输入法候选），所以直接引导去点问题
    if renpy.variant("touch"):
        text "点上面的问题问史官｜手机暂不支持拼音输入":
            xalign 0.5
            ypos 892
            font STORY_FONT
            size 19
            color "#7a6845"
    else:
        text "Enter 发送　・　Shift + Enter 换行":
            xalign 0.5
            ypos 892
            font STORY_FONT
            size 19
            color "#5c4f38"

    # ---------- 底部按钮 ----------
    textbutton "清 空":
        style "game_button"
        text_size 22
        xpos 372
        ypos 944
        action Function(agent_reset)

    textbutton "返 回":
        style "game_button"
        text_size 24
        xalign 0.5
        xoffset 420
        ypos 944
        action Return()

    # 键盘：回车发送、Esc 返回
    key "K_RETURN" action Function(agent_send)
    key "K_ESCAPE" action Return()
