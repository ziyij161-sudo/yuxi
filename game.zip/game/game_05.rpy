# ============================================================
# 《假如你是传国玉玺》—— game_05：千年流转（跳一跳・摆动蓄力版）
# 本系列第 5 个游戏；全部代码合并在本文件中，不再拆分。
# 分辨率：1920 x 1080，扁平国风，玩家代入传国玉玺在 8 个朝代间跳跃流转。
#
# 本文件包含：
#   第一部分：逻辑（变量、8 时代数据、蓄力指针、真抛物线飞行、label 流程）
#   第二部分：界面（cx_dialog / notify / cx_swing）
#
# 玩法：点击屏幕让摆动的指针停下 → 再点「起 跳」。
#   落点在绿区正中 = 完美；绿区两侧黄区 = 普通；偏出平台 = 坠落重跳。
#
# 素材目录（统一命名 _05）：
#   - 图片：game/images_05/（8 朝代 bg_/plat_/era_、玉玺两形态）
#   - 音频：game/audio_05/（cx_bg / cx_sad BGM + 各音效，缺文件静默跳过）
#
# ⚠ 重要：
#   1. Ren'Py 只在游戏启动时扫描一次文件。
#      加素材/改代码后必须 Shift+R 热重载或完全重启游戏。
#   2. 本文件是唯一代码文件，旧的 script.rpy / screens.rpy
#      （及 .rpyc 编译残留）已删除，勿再放回。
# ============================================================

# ============================================================
# 第一部分：逻辑
# ============================================================

# ---------- 游戏名：统一在 options.rpy 里定义（config.name = 假如你是传国玉玺） ----------

# ============================================================
# 《假如你是传国玉玺》—— game_05：千年流转（跳一跳・摆动蓄力版，单文件整合版）
# game_05.rpy（逻辑部分）：变量定义、初始化逻辑、label 跳转逻辑
# 分辨率：1920 x 1080
#
# 玩法：玩家代入传国玉玺，在 8 个时代之间"跳跃"易主：
#   秦(咸阳宫) → 汉(未央宫) → 新(长乐宫・崩角) → 汉末(烽烟)
#   → 魏(受禅台) → 晋(江左) → 隋唐(太极宫) → 后唐(玄武楼・结局)
#
# 操作：点击屏幕让摆动的指针停下 → 再点「起 跳」。
#   落点在绿区正中 = 完美；绿区两侧黄区 = 普通；
#   偏出平台 = 坠落（不失败，插对白后原地重跳）。
#
# 素材目录：
#   背景图：game/images_05/bg_*.jpg（8 张，一时代一张）（8 张，一时代一张）
#   平台：  game/images_05/plat_*.png（双手托举案几，锚点=顶面中心）
#   题字牌：game/images_05/era_*.png（小篆竖排朝代题字）
#   玉玺：  game/images_05/seal_full.png / seal_broken.png（金镶角版）
#   音频：  game/audio_05/（见下方 CX_SFX 映射，缺文件自动静默跳过）
#
# ⚠ 重要：Ren'Py 只在游戏启动时扫描一次文件。
#   加素材/改代码后必须 Shift+R 热重载或完全重启游戏。
# ============================================================
init python:
    import os
    import time

    # ---------- 分辨率设定（画面自适应的关键） ----------
    # 本游戏所有坐标、字号均按 1920x1080 设计。
    # Ren'Py 会把虚拟分辨率等比缩放到玩家的窗口/全屏大小：
    # 任何屏幕上画面都自动适配、比例不变形、坐标不错位。
    # （此前由 gui.rpyc 提供，清理残留后必须在此显式声明）
    config.screen_width = 1920
    config.screen_height = 1080

    # ---------- 字体自动探测 ----------
    def cx_get_font():
        # 优先使用项目自带的中文字体（跨平台可用）
        if renpy.loadable("SourceHanSansLite.ttf"):
            return "SourceHanSansLite.ttf"
        if renpy.loadable("msyh.ttc"):
            return "msyh.ttc"
        for p in (
            "C:/Windows/Fonts/msyh.ttc",
            "C:/Windows/Fonts/msyh.ttf",
            "C:/Windows/Fonts/simhei.ttf",
        ):
            if os.path.isfile(p):
                return p
        return "SourceHanSansLite.ttf"
    CX_FONT = cx_get_font()
    # ---------- 修复对白/菜单中文乱码 ----------
    # 注意：font_replacement_map 的键和值都必须是 (字体, 粗体, 斜体) 三元组
    for _fname in ("DejaVuSans.ttf", "gui/default-font.ttf"):
        for _bold in (False, True):
            for _italic in (False, True):
                config.font_replacement_map[(_fname, _bold, _italic)] = (CX_FONT, False, False)
    for _key in ("text_font", "name_text_font", "interface_text_font"):
        try:
            _f = getattr(gui, _key)
            if _f:
                for _bold in (False, True):
                    for _italic in (False, True):
                        config.font_replacement_map[(_f, _bold, _italic)] = (CX_FONT, False, False)
        except Exception:
            pass
    # ---------- 几何常量 ----------
    CX_X0 = 430          # 当前平台锚点 x
    CX_Y0 = 850          # 当前平台锚点 y（顶面中心）
    CX_MAXD = 1600.0     # 满蓄力的水平位移
    CX_PERFECT = 80.0    # 完美落点半宽（屏幕 px）
    CX_GOOD = 250.0      # 平台半宽（普通落点判定，屏幕 px）
    CX_PLAT_ZOOM = 0.55
    CX_PLAT_ANCHOR = 0.698   # 平台图锚点 y 比例（顶面中心 300/430）
    CX_SEAL_ZOOM = 0.24   # 玉玺立绘画布 1235x815，按宽缩放（显示约 296px 宽）
    CX_BAR_X = 460
    CX_BAR_Y = 930
    CX_BAR_W = 1000
    CX_BAR_H = 46
    CX_APEX_Y = 250      # 跳跃弧线顶点
    # ---------- 8 个时代数据 ----------
    # tx/ty：本站时"下一站平台"的落点锚点
    # dur：蓄力指针单程摆动秒数（越小越难）
    # lines：首次到站时的玉玺第一视角对白
    CX_ERAS = [
        dict(
            id="qin", name="秦 ・ 咸阳宫",
            bg="images_05/bg_qin.jpg", plat="images_05/plat_qin.png", era="images_05/era_qin.png",
            tx=1050, ty=800, dur=1.20,
            lines=[
                "皇帝的手掌温热而有力。他把我举向群臣，日光落在刻痕上。",
                "可我隐约听见——帝国的丧钟，已在远方的沙丘上酝酿。",
            ],
        ),
        dict(
            id="han", name="汉 ・ 未央宫",
            bg="images_05/bg_han.jpg", plat="images_05/plat_han.png", era="images_05/era_han.png",
            tx=1150, ty=760, dur=1.10,
            lines=[
                "大秦只有十五年。沙丘的风、戏亭的火，我在乱局里换了三任主人。",
                "最后，是沛县出身的刘邦把我捧进未央宫。汉家的手掌宽厚，一捧，就是四百年。",
            ],
        ),
        dict(
            id="xin", name="新 ・ 长乐宫",
            bg="images_05/bg_xin.jpg", plat="images_05/plat_xin.png", era="images_05/era_xin.png",
            tx=1250, ty=780, dur=1.00,
            lines=[
                "可是，王莽来了。他篡了汉家的天下，还想要汉家的玺。",
            ],
        ),
        dict(
            id="hanmo", name="汉末 ・ 烽烟",
            bg="images_05/bg_hanmo.jpg", plat="images_05/plat_hanmo.png", era="images_05/era_hanmo.png",
            tx=1180, ty=700, dur=0.95,
            lines=[
                "洛阳大火。十常侍挟帝出逃，我被投进井底，又在孙坚的怀里重见天日。",
                "从这天起，我不再是国器，而是军阀赌桌上的筹码。",
            ],
        ),
        dict(
            id="wei", name="魏 ・ 受禅台",
            bg="images_05/bg_wei.jpg", plat="images_05/plat_wei.png", era="images_05/era_wei.png",
            tx=1300, ty=740, dur=0.85,
            lines=[
                "曹丕在受禅台上接过我，命人刻下“大魏受汉传国玺”。",
                "我头一回被用来证明“禅让”，但我记得汉献帝交出我的那只手在抖。",
            ],
        ),
        dict(
            id="jin", name="晋 ・ 江左",
            bg="images_05/bg_jin.jpg", plat="images_05/plat_jin.png", era="images_05/era_jin.png",
            tx=1220, ty=680, dur=0.80,
            lines=[
                "五胡的战马踏碎洛阳。我在刘聪、石勒、冉闵的手里辗转千里，每一双手都沾着血。",
                "再后来，江南建康的天子没有我，被讥为“白版天子”。人们终于承认我就是正统本身。",
            ],
        ),
        dict(
            id="suitang", name="隋唐 ・ 太极宫",
            bg="images_05/bg_suitang.jpg", plat="images_05/plat_suitang.png", era="images_05/era_suitang.png",
            tx=1350, ty=640, dur=0.75,
            lines=[
                "隋文帝灭陈，把我迎回长安。到了太宗皇帝手里，九天宫阙，万国衣冠。",
                "这是我的黄金时代。可黄金时代，总是最短的。",
            ],
        ),
        dict(
            id="houtang", name="后唐 ・ 玄武楼",
            bg="images_05/bg_houtang.jpg", plat="images_05/plat_houtang.png", era="images_05/era_houtang.png",
            tx=1350, ty=640, dur=0.75,
            lines=[
                "五代烽烟。我走过后梁的宫阙、后唐的兵戈，此刻在末帝李从珂的怀里。",
                "玄武楼很高，能望见洛阳城外的烽火。我知道——这是最后一站了。",
            ],
        ),
    ]
    CX_FALL_LINES = [
        "我重重坠地——玉身剧痛，可夺玺的人们，不会等我养伤。",
        "又摔落了。乱世之中，连玉也会跌进尘埃。",
        "这一跳失了手。手掌换了一双又一双，权柄却不曾停歇。",
    ]
    # ---------- 音效定义（缺文件静默跳过） ----------
    CX_SFX = {
        "click":   ["audio_05/click.wav", "audio_05/click.ogg", "audio_05/click.mp3"],
        "charge":  ["audio_05/charge.wav", "audio_05/charge.ogg", "audio_05/charge.mp3"],
        "jump":    ["audio_05/jump.wav", "audio_05/jump.ogg", "audio_05/jump.mp3"],
        "perfect": ["audio_05/perfect.wav", "audio_05/perfect.ogg", "audio_05/perfect.mp3"],
        "good":    ["audio_05/good.wav", "audio_05/good.ogg", "audio_05/good.mp3"],
        "fall":    ["audio_05/fall.wav", "audio_05/fall.ogg", "audio_05/fall.mp3"],
        "snap":    ["audio_05/snap.wav", "audio_05/snap.ogg", "audio_05/snap.mp3"],
        "gong":    ["audio_05/gong.wav", "audio_05/gong.ogg", "audio_05/gong.mp3"],
    }
    def cx_play_sound(name):
        for f in CX_SFX.get(name, []):
            if renpy.loadable(f):
                try:
                    renpy.sound.play(f)
                except Exception:
                    pass
                return
    def cx_play_music(name, fadein=1.0):
        for f in (name, name.replace(".wav", ".ogg"), name.replace(".wav", ".mp3")):
            if renpy.loadable(f):
                try:
                    renpy.music.play(f, fadein=fadein, loop=True)
                except Exception:
                    pass
                return
    def cx_stop_music(fadeout=1.5):
        try:
            renpy.music.stop(fadeout=fadeout)
        except Exception:
            pass
    # ---------- 手机端真机震动（桌面端 no-op） ----------
    # ★ 打包 Android 时需在 options.rpy 里声明：
    #   define build.android_permissions = ["VIBRATE"]
    def cx_vibrate(ms=30):
        # Ren'Py 8.x 中 renpy.android 是 bool 常量（旧版是函数），做兼容处理
        try:
            is_android = renpy.android() if callable(renpy.android) else bool(renpy.android)
        except Exception:
            return
        if not is_android:
            return
        try:
            from jnius import autoclass
            activity = autoclass("org.renpy.android.PythonActivity").mActivity
            Context = autoclass("android.content.Context")
            VibrationEffect = autoclass("android.os.VibrationEffect")
            try:
                manager = activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE)
                vibrator = manager.getDefaultVibrator()
            except Exception:
                vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
            if vibrator is None:
                return
            effect = VibrationEffect.createOneShot(int(ms), VibrationEffect.DEFAULT_AMPLITUDE)
            vibrator.vibrate(effect)
        except Exception:
            pass
    # ---------- 蓄力指针 ----------
    def cx_phase_value():
        """按时间计算指针相位（0~1 的三角波），与显示用 DD 完全同源"""
        dur = CX_ERAS[cx_i]["dur"] if 0 <= cx_i < len(CX_ERAS) else 1.0
        t = (time.time() - cx_swing_t0) % (2.0 * dur)
        return t / dur if t <= dur else 2.0 - t / dur
    def cx_freeze_store():
        """点击停摆：把此刻相位存为蓄力值（Function 调用，返回 None 不结束交互）"""
        global cx_frozen_p
        cx_frozen_p = cx_phase_value()
        cx_play_sound("click")
    def cx_unfreeze():
        """重摆：清除冻结蓄力值，指针恢复摆动"""
        global cx_frozen_p
        cx_frozen_p = None
        cx_play_sound("click")
    def cx_ptr_dd(st, at):
        """蓄力指针的动态显示件：每帧重绘，与判定同用一套时钟"""
        p = cx_frozen_p if cx_frozen_p is not None else cx_phase_value()
        x = int(p * (CX_BAR_W - 12))
        d = Composite((CX_BAR_W, CX_BAR_H), (x, 0), Solid("#ffe9b0", xysize=(12, CX_BAR_H)))
        return (d, 0)
    def cx_req_p():
        """本跳需要的蓄力值（下一站平台位置换算成蓄力条比例）"""
        if cx_i + 1 >= len(CX_ERAS):
            return 0.5
        return (CX_ERAS[cx_i + 1]["tx"] - CX_X0) / CX_MAXD
    def cx_land(p):
        """按蓄力值判定落点：perfect / good / fall，并把落点存入 cx_land_x"""
        global cx_land_x, cx_res
        p = max(0.0, min(1.0, p))
        cx_land_x = CX_X0 + p * CX_MAXD
        if cx_i + 1 >= len(CX_ERAS):
            cx_res = "good"
            return cx_res
        d = abs(cx_land_x - CX_ERAS[cx_i + 1]["tx"])
        if d <= CX_PERFECT:
            cx_res = "perfect"
        elif d <= CX_GOOD:
            cx_res = "good"
        else:
            cx_res = "fall"
        cx_land_x = max(120.0, min(1800.0, cx_land_x))
        return cx_res
    def cx_seal_img():
        return "images_05/seal_broken.png" if cx_seal_broken else "images_05/seal_full.png"
    # ---------- 真抛物线跳跃（DynamicDisplayable 逐帧驱动，物理轨迹） ----------
    # cx_arc = [x0, y0, x1, y1, 顶点y, 是否坠落, 总时长]，由 cx_try_jump 每跳前赋值
    def cx_flight_dd(st, at):
        x0, y0, x1, y1, ay, fall, T = cx_arc
        t = min(1.0, st / T)
        # x 匀速推进，y 为二次曲线（过起点/终点、顶点 ay），即标准抛物线
        x = x0 + (x1 - x0) * t
        y = y0 + (y1 - y0) * t - ((y0 + y1) / 2.0 - ay) * 4.0 * t * (1.0 - t)
        if fall and t >= 0.55:
            a = max(0.0, 1.0 - (t - 0.55) / 0.45)   # 坠落：下落半程逐渐淡出
        else:
            a = 1.0
        # 锁定最终渲染尺寸（与站台静止时 zoom CX_SEAL_ZOOM 完全一致）
        _sw = int(1235 * CX_SEAL_ZOOM)   # 296
        _sh = int(815 * CX_SEAL_ZOOM)    # 195
        # 注意：Composite 内部强制子件左上角对齐到给定坐标（源码 Position(xanchor=0)），
        # 传给子件的锚点会被覆盖 → 必须手动换算，让 (x, y) 始终是"底边中心"
        img = Transform(cx_seal_img(), xysize=(_sw, _sh), alpha=a)
        d = Composite((1920, 1080), (int(x - _sw / 2), int(y - _sh)), img)
        return (d, None if t >= 1.0 else 0)
# ---------- 存档变量 ----------
default cx_i = 0                 # 当前站序号
default cx_swing_t0 = 0.0        # 摆动起始时间戳
default cx_frozen_p = None       # 停摆时的蓄力值
default cx_land_x = 0.0          # 最近一次落点 x
default cx_res = ""              # 最近一次判定结果
default cx_seal_broken = False   # 是否已崩角（金镶角形态）
default cx_seal_hidden = False   # 玉玺是否已随坠落淡出（重跳前需升回左手）
default cx_arc = [0.0, 0.0, 0.0, 0.0, 0.0, False, 0.95]   # 抛物线参数包
default cx_perfect_n = 0         # 完美落点计数
default cx_jumps = 0             # 成功跳跃计数
default cx_intro_done = False    # 开场对白只播一次
default era_visited = []         # 各站对白是否已播
# ---------- 入口（Ren'Py 强制要求，勿删） ----------
label game_06:
    # 第五章开场视频（videos/ch05.webm，可暂停 / 倍速 / 跳过）
    call play_chapter_movie(5)
    # 视频期间音乐淡出，播完接回全篇统一配乐
    play music "audio/common/calm.ogg" fadein 2.0 loop
    scene expression "images_05/bg_qin.jpg" with dissolve
    if not cx_intro_done:
        call screen chapter_intro(
            "千年流转",
            "公元前 221 年　・　咸阳宫　→　公元 936 年　・　洛阳玄武楼",
            [
                "从这里开始，我的一生就是一次次易手。",
                "每一双手都以为，抓住我，就抓住了天下。",
            ],
            [
                "点击屏幕，让摆动的指针停住，再点「起 跳」。",
                "落在绿区正中为完美，落在黄区为普通，偏出平台则会坠落重跳。",
                "若不愿一次次跳，也可以点右上角「跳 过」，直接走到最后一站。",
            ],
        )
        call screen cx_dialog("公元前 221 年，咸阳宫。李斯在我身上刻下了最后一笔。")
        call screen cx_dialog("受命于天，既寿永昌。从这一天起，我不再只是一块美玉——我是传国玉玺。")
        call screen cx_dialog("皇帝亲手执起我。我第一次俯瞰这座天下最大的宫殿，第一次背负着“天下”的重量。")
        call screen cx_dialog("可我知道，我的一生不会安稳。我将辗转于无数双手之间：帝王、太后、军阀、末主……看王朝兴起，也看王朝倾覆。")
        $ cx_intro_done = True
    jump cx_main
# ---------- 千年流转主流程 ----------
label cx_main:
    $ cx_i = 0
    $ cx_seal_broken = False
    $ cx_perfect_n = 0
    $ cx_jumps = 0
    $ era_visited = [False] * len(CX_ERAS)
    $ cx_play_music("audio_05/cx_bg.wav", fadein=1.0)
    while cx_i < len(CX_ERAS):
        if cx_i == len(CX_ERAS) - 1:
            # 最后一站：玄武楼结局（不再跳跃）
            call cx_ending
            jump cx_after
        call cx_station
        # 跳跃循环：坠落则插对白后原地重跳
        $ cx_res = "fall"
        while cx_res == "fall":
            call cx_try_jump
            $ cx_res = _return
            if cx_res == "skip":
                jump cx_skip
        # 成功抵达下一站：换站钟声
        $ cx_i += 1
    return
# ---------- 到站布景 + 首次到站对白 + 特殊事件 ----------
label cx_station:
    $ era = CX_ERAS[cx_i]
    $ cx_play_sound("gong")
    scene expression era["bg"] with dissolve
    show expression era["plat"] as cxplat0:
        zoom CX_PLAT_ZOOM
        xpos CX_X0 ypos CX_Y0 xanchor 0.5 yanchor CX_PLAT_ANCHOR
    if cx_i + 1 < len(CX_ERAS):
        $ nxt = CX_ERAS[cx_i + 1]
        show expression nxt["plat"] as cxplat1:
            zoom CX_PLAT_ZOOM
            xpos nxt["tx"] ypos nxt["ty"] xanchor 0.5 yanchor CX_PLAT_ANCHOR
    show expression era["era"] as cxplate:
        zoom 0.5
        xpos 70 ypos 300
    show expression cx_seal_img() as cxseal:
        zoom CX_SEAL_ZOOM
        xpos CX_X0 ypos (CX_Y0 - 70) xanchor 0.5 yanchor 1.0
    if not era_visited[cx_i]:
        $ _li = 0
        while _li < len(era["lines"]):
            call screen cx_dialog(era["lines"][_li])
            $ _li += 1
        $ era_visited[cx_i] = True
    # 特殊事件：新朝・太后掷玺崩角
    if cx_i == 2 and not cx_seal_broken:
        call cx_break_event
    return
# ---------- 崩角事件（历史梗：金镶玉） ----------
label cx_break_event:
    call screen cx_dialog("王莽的使者闯入长乐宫，向太后索要传国玺。")
    call screen cx_dialog("太后怒喝：“我汉家老寡妇，早晚要死，也不配传这枚玺！”")
    $ cx_play_sound("snap")
    $ cx_vibrate(60)
    pause 0.4
    call screen cx_dialog("咔——我重重砸在殿前的金砖上，崩落了一角。")
    show expression "images_05/seal_broken.png" as cxseal:
        zoom CX_SEAL_ZOOM
        xpos CX_X0 ypos (CX_Y0 - 70) xanchor 0.5 yanchor 1.0
    call screen cx_dialog("此后黄金镶角，世人称“金镶玉”。每一双手抚过我时，都摸得到那道疤。")
    $ cx_seal_broken = True
    return
# ---------- 单次跳跃：摆动蓄力 → 判定 → 弧线动画 ----------
label cx_try_jump:
    $ cx_swing_t0 = time.time()
    $ cx_frozen_p = None
    # 坠落重跳：玉玺从平台下方缓缓升回左手（不能凭空出现）
    # ★ 上一显示件是飞行 DD（定格在坠落终点、alpha 0），同 tag show
    #   未列出的属性会继承其变换状态 → 必须 xPos/ypos/anchor/zoom/alpha 全显式给出
    if cx_seal_hidden:
        show expression cx_seal_img() as cxseal:
            xpos CX_X0 ypos (CX_Y0 - 10) xanchor 0.5 yanchor 1.0 zoom CX_SEAL_ZOOM alpha 0.0
            easein 0.8 ypos (CX_Y0 - 70) alpha 1.0
        pause 0.9
        $ cx_seal_hidden = False
    call screen cx_swing
    $ act = _return
    if act == "skip":
        return "skip"
    # act == "jump"：按停摆时的蓄力值判定
    $ _res = cx_land(cx_frozen_p if cx_frozen_p is not None else 0.0)
    $ era = CX_ERAS[cx_i]
    $ has_next = (cx_i + 1 < len(CX_ERAS))
    $ nxt = CX_ERAS[cx_i + 1] if has_next else era
    $ lx = cx_land_x
    $ ay = CX_APEX_Y
    $ ly = (nxt["ty"] - 70) if _res != "fall" else 1160.0
    $ cx_arc = [float(CX_X0), float(CX_Y0 - 70), float(lx), float(ly),
                float(ay), (_res == "fall"), 0.95]
    $ cx_play_sound("jump")
    # 飞行中的玉玺由 DynamicDisplayable 每帧重绘（抛物线），落点=下一双手
    # ★ 必须显式给出全部摆放属性：同 tag show 不带属性会继承上一显示件的
    #   变换状态（含 zoom 0.24），导致全屏合成层被缩小、玉玺变小
    show expression DynamicDisplayable(cx_flight_dd) as cxseal:
        xpos 0 ypos 0 xanchor 0 yanchor 0 zoom 1.0
    pause 1.0
    if _res == "perfect":
        $ cx_play_sound("perfect")
        $ renpy.notify("完美落点！")
        $ cx_perfect_n += 1
        $ cx_vibrate(50)
    elif _res == "good":
        $ cx_play_sound("good")
        $ cx_vibrate(30)
    else:
        $ cx_play_sound("fall")
        $ cx_vibrate(90)
    pause 0.5
    if _res == "fall":
        $ _fall = renpy.random.choice(CX_FALL_LINES)
        call screen cx_dialog(_fall)
        # 标记玉玺已随坠落淡出，下次重跳前先把它升回左手
        $ cx_seal_hidden = True
        return "fall"
    $ cx_jumps += 1
    return _res
# ---------- 终局：玄武楼・自焚失踪 ----------
label cx_ending:
    $ era = CX_ERAS[cx_i]
    $ cx_stop_music(fadeout=1.0)
    $ cx_play_music("audio_05/cx_sad.wav", fadein=1.5)
    scene expression era["bg"] with dissolve
    show expression era["plat"] as cxplat0:
        zoom CX_PLAT_ZOOM
        xpos CX_X0 ypos CX_Y0 xanchor 0.5 yanchor CX_PLAT_ANCHOR
    show expression era["era"] as cxplate:
        zoom 0.5
        xpos 70 ypos 300
    show expression cx_seal_img() as cxseal:
        zoom CX_SEAL_ZOOM
        xpos CX_X0 ypos (CX_Y0 - 70) xanchor 0.5 yanchor 1.0
    if not era_visited[cx_i]:
        $ _li = 0
        while _li < len(era["lines"]):
            call screen cx_dialog(era["lines"][_li])
            $ _li += 1
        $ era_visited[cx_i] = True
    call cx_fire
    return
# ---------- 大火场景（跳过按钮可直接进入本段） ----------
label cx_fire:
    call screen cx_dialog("公元 936 年冬，石敬瑭引契丹兵入洛阳。末帝李从珂携我登上玄武楼。")
    call screen cx_dialog("他抱着我，轻声说：“宁见焚，不为降。”")
    call screen cx_dialog("火，起来了。")
    $ cx_play_sound("fall")
    show expression cx_seal_img() as cxseal:
        zoom CX_SEAL_ZOOM
        xpos CX_X0 ypos (CX_Y0 - 70) xanchor 0.5 yanchor 1.0
        easein 2.2 ypos 1180 alpha 0.0
    pause 2.4
    $ _stat = "（此程共 {} 跳，其中完美落点 {} 次。）".format(cx_jumps, cx_perfect_n)
    call screen cx_dialog(_stat)

    # ---------- 火光里的回声：与历代帝王对话（虚构） ----------
    call screen cx_dialog("火舌舔上我的那一刻，我听见了很多声音。")
    call screen cx_dialog("秦始皇：“朕以蓝田之玉刻此八字，欲传之万世。”")
    call screen cx_dialog("“陛下，”我说，“大秦只走了十五年。”")
    call screen cx_dialog("他沉默了很久：“那八个字，我刻的是天命，不是我的名字。”")
    call screen cx_dialog("汉武帝：“朕要你替朕压住四方的风。”")
    call screen cx_dialog("“可您晚年下过一道轮台诏，”我说，“说百姓太苦。”")
    call screen cx_dialog("他笑了：“原来你还记得那道诏。”")
    call screen cx_dialog("唐太宗：“朕得玺于乱世，却不愿后人只说朕得玺。”")
    call screen cx_dialog("“所以您把‘水能载舟’说给人听，”我说，“而不是刻在我身上。”")
    call screen cx_dialog("最后是李从珂。他把我抱得更紧：“宁见焚，不为降。”")
    call screen cx_dialog("“可您抱着的，”我说，“只是一块石头。”")
    call screen cx_dialog("“不。”他说，“是朕这一生的体面。”")

  
    # ---------- 抒情：千年流转 ----------
    call screen cx_dialog("我这才明白，两千年里，人们捧我、抢我、摔我、镶我、藏我。")
    call screen cx_dialog("他们都以为，得到我，就得到了天下。")
    call screen cx_dialog("可天下从来不在我的身体里。")
    call screen cx_dialog("它在粮仓里，在田垄上，在一张张催粮的诏书背面，在那些没被写进史书的名字里。")
    call screen cx_dialog("我只是一块蓝田玉。被刻过、摔过、镶过、烧过。")
    call screen cx_dialog("自此千年，再无人见过我的真身。")
    call screen cx_dialog("后世帝王补刻过无数枚“传国玺”，可它们都知道——真正的我，停在了 936 年的火光里。")

    # ---------- 升华 ----------
    call screen cx_dialog("明朝的大臣傅瀚说过一句话：受命以德，不以玺也。")
    call screen cx_dialog("所以，若你问我如今在哪里——")
    call screen cx_dialog("我可能碎在某条河底的泥沙里，可能被砌进了哪一段城墙，")
    call screen cx_dialog("也可能正躺在一个孩子的抽屉里，被他当作一块好看的石头。")
    call screen cx_dialog("我在中国的任何一个角落。")
    call screen cx_dialog("而真正的传国玉玺，从来不在玉里。")
    call screen cx_dialog("它在每一个愿意把日子过好的人心里。")
    call screen cx_dialog("受命于天，既寿永昌——")
    call screen cx_dialog("天，是万民；昌，是万家灯火。")

    $ cx_stop_music(fadeout=2.0)
    return
# ---------- 本章收尾：全剧历史讲完，进入番外 ----------
label cx_after:
    scene expression "images_05/bg_houtang.jpg" with dissolve
    call screen cx_dialog("火光熄了，千年也过去了。")
    call screen cx_dialog("正史里再没有我的消息。可我还在——在每一处你愿意多看一眼的地方。")
    call screen cx_dialog("（接下来，是一段不属于正史的番外。）")
    # ★ 已接入主线：进入番外（game_06.rpy 的 torch_extra）
    jump torch_extra
# ---------- 跳过：略过大火前的全部站点，直接进入玄武楼大火场景 ----------
label cx_skip:
    $ cx_i = len(CX_ERAS) - 1          # 直达最后一站：后唐 ・ 玄武楼
    $ cx_seal_broken = True            # 走完跳过时按史实以"金镶角"形态赴火
    $ era = CX_ERAS[cx_i]
    $ cx_stop_music(fadeout=1.5)
    $ cx_play_music("audio_05/cx_sad.wav", fadein=1.5)
    scene expression era["bg"] with dissolve
    show expression era["plat"] as cxplat0:
        zoom CX_PLAT_ZOOM
        xpos CX_X0 ypos CX_Y0 xanchor 0.5 yanchor CX_PLAT_ANCHOR
    show expression era["era"] as cxplate:
        zoom 0.5
        xpos 70 ypos 300
    show expression cx_seal_img() as cxseal:
        zoom CX_SEAL_ZOOM
        xpos CX_X0 ypos (CX_Y0 - 70) xanchor 0.5 yanchor 1.0
    call screen cx_dialog("（千年流转，一眼望尽。你收住脚步，径直来到了最后一站——后唐 玄武楼。）")
    call cx_fire
    jump cx_after

# ============================================================
# 第二部分：界面
# ============================================================

screen cx_dialog(txt):
    modal True
    zorder 300
    # 点击屏幕任意位置继续（放在最底层）
    button:
        xfill True
        yfill True
        background None
        action Return()
    # 底部对话框
    frame:
        xalign 0.5
        yalign 0.92
        xmaximum 1640
        background "#0d0a07e6"
        padding (70, 36)
        vbox:
            spacing 10
            text "[txt]":
                font CX_FONT
                size 48
                color "#e8d5a3"
            text "（点击任意处继续）":
                font CX_FONT
                size 22
                color "#8f7f5e"
# ---------- 轻提示（renpy.notify 自动调用，1.4 秒后自动消失） ----------
screen notify(message=None):
    zorder 400
    frame:
        xpos 0.5
        xanchor 0.5
        ypos 230
        background "#0d0a07e6"
        padding (44, 18)
        text "[message]":
            font CX_FONT
            size 42
            color "#ffe9b0"
    timer 1.4 action Hide("notify")
# ---------- 蓄力摆动主界面 ----------
# 场景（背景/平台/玉玺/题字牌）由 label 里的 show 语句铺在底层，
# 本 screen 只负责：站名、下一站提示、蓄力条与指针、按钮。
screen cx_swing():
    modal True
    default cx_frozen = False
    # ---- 全屏点击：停摆（未冻结时） ----
    if not cx_frozen:
        button:
            xfill True
            yfill True
            background None
            action [Function(cx_freeze_store), SetScreenVariable("cx_frozen", True)]
    # ---- 顶栏：当前站名 ----
    $ cur = CX_ERAS[cx_i]
    frame:
        xalign 0.5
        ypos 30
        background "#0d0a07b8"
        padding (60, 18)
        text cur["name"]:
            font CX_FONT
            size 54
            color "#e8d5a3"
    # ---- 下一站提示（悬浮在目标平台上方） ----
    if cx_i + 1 < len(CX_ERAS):
        $ nxt = CX_ERAS[cx_i + 1]
        text "下一站 ・ " + nxt["name"]:
            font CX_FONT
            size 30
            color "#cbb98f"
            xpos nxt["tx"]
            xanchor 0.5
            ypos nxt["ty"] - 235
            yanchor 1.0
    # ---- 蓄力条：轨道 + 黄区（普通）+ 绿区（完美）+ 指针 ----
    fixed:
        xpos CX_BAR_X
        ypos CX_BAR_Y
        xysize (CX_BAR_W, CX_BAR_H)
        add Solid("#141008e0") xysize (CX_BAR_W, CX_BAR_H)
        # 黄区：普通落点范围（中心对齐所需蓄力值）
        $ _gw = CX_GOOD / CX_MAXD
        add Solid("#854f0ba8"):
            xpos int((cx_req_p() - _gw) * CX_BAR_W)
            xysize (int(_gw * 2 * CX_BAR_W), CX_BAR_H)
        # 绿区：完美落点范围
        $ _gh = CX_PERFECT / CX_MAXD
        add Solid("#3b6d11d0"):
            xpos int((cx_req_p() - _gh) * CX_BAR_W)
            xysize (int(_gh * 2 * CX_BAR_W), CX_BAR_H)
        # 指针（与判定同一时钟，停摆后定格在 cx_frozen_p）
        add DynamicDisplayable(cx_ptr_dd)
    # ---- 操作提示 / 冻结后的按钮 ----
    if not cx_frozen:
        text "点击屏幕，让指针停在绿区正中 → 再点「起 跳」":
            font CX_FONT
            size 30
            color "#cbb98f"
            xpos 0.5
            xanchor 0.5
            ypos 880
        # 跳过按钮（放最后，保证在最上层可点）
        textbutton "跳 过":
            action [Function(cx_play_sound, "click"), Return("skip")]
            text_font CX_FONT
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            background "#3a2e20c8"
            hover_background "#5a4630e0"
            padding (34, 14)
            xalign 0.985
            ypos 32
    else:
        hbox:
            xalign 0.5
            ypos 870
            spacing 60
            textbutton "起 跳":
                action [Function(cx_play_sound, "jump"), Return("jump")]
                text_font CX_FONT
                text_size 40
                text_color "#ffe9b0"
                text_hover_color "#ffffff"
                background "#3b6d11d8"
                hover_background "#3b6d11f2"
                padding (44, 16)
            textbutton "重 摆":
                action [Function(cx_unfreeze), SetScreenVariable("cx_frozen", False)]
                text_font CX_FONT
                text_size 34
                text_color "#e8d5a3"
                text_hover_color "#ffffff"
                background "#3a2e20c8"
                hover_background "#5a4630e0"
                padding (34, 14)
        # 冻结时也要能跳过（右上角）
        textbutton "跳 过":
            action [Function(cx_play_sound, "click"), Return("skip")]
            text_font CX_FONT
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            background "#3a2e20c8"
            hover_background "#5a4630e0"
            padding (34, 14)
            xalign 0.985
            ypos 32
