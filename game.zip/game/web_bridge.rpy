# ==========================================================
# Web（浏览器）桥接层
# ----------------------------------------------------------
# Ren'Py 打包成网页版后，引擎内部是 WebAssembly，网页元素（<video>、
# 浏览器输入框）都活在 JS 那一侧。这里放一层很薄的包装：
#
#   web_js(expr)        在浏览器里求值一段 JS，取回字符串
#   web_video(...)      直接控制 <video> 元素（暂停/继续/变速/停止）
#   web_video_time()    读取视频真实进度
#   web_prompt(...)     调浏览器原生输入框（能用系统输入法打中文）
#
# 桌面版（非 Web 构建）里这些函数一律安全返回空值，调用方会自动
# 退回原来的本地逻辑，所以同一份代码两端都能跑。
# ==========================================================

init -20 python:

    import json as _json

    def _web_text(v):
        """把 JS 返回的东西统一成 str。"""
        if v is None:
            return ""
        if isinstance(v, bytes):
            try:
                return v.decode("utf-8", "ignore")
            except Exception:
                return ""
        return str(v)

    def web_js(expr):
        """在网页版里执行一段 JS 表达式，返回字符串结果。
        桌面版、或浏览器没给接口时返回空串。"""
        if not renpy.emscripten:
            return ""

        try:
            import emscripten
        except Exception:
            return ""

        fn = getattr(emscripten, "run_script_string", None)
        if fn is None:
            return ""

        try:
            return _web_text(fn(expr))
        except Exception:
            return ""

    # 找页面上的 <video>：Ren'Py 的 web 版只用一个影音频道，
    # 所以整页最多只有一个 video 元素，直接 querySelector 最省事。
    _WEB_FIND_VIDEO = "(function(){var v=document.querySelector('video');"

    def web_video(action, value=None):
        """直接操作浏览器里的 <video> 元素。

        pause / play  原地暂停与续播（不会重新加载，所以不会从头开始）
        rate          实时变速（playbackRate，不用换文件）
        stop          停掉并卸载，避免元素残留在页面上
        """
        if not renpy.emscripten:
            return False

        if action == "pause":
            js = _WEB_FIND_VIDEO + "if(!v)return '0';try{v.pause();}catch(e){}return '1';})()"
        elif action == "play":
            # 这是用户点按钮触发的，浏览器允许此时取消静音
            js = (
                _WEB_FIND_VIDEO
                + "if(!v)return '0';try{v.muted=false;var p=v.play();"
                + "if(p&&p.catch)p.catch(function(){});}catch(e){}return '1';})()"
            )
        elif action == "rate":
            try:
                rate = float(value)
            except Exception:
                rate = 1.0
            js = (
                _WEB_FIND_VIDEO
                + "if(!v)return '0';try{v.playbackRate=%s;}catch(e){}return '1';})()" % rate
            )
        elif action == "stop":
            js = (
                _WEB_FIND_VIDEO
                + "if(!v)return '0';try{v.pause();v.removeAttribute('src');v.load();}"
                + "catch(e){}return '1';})()"
            )
        else:
            return False

        return web_js(js) == "1"

    def web_video_time():
        """浏览器里视频的当前播放进度（秒）。没在播 / 桌面版返回 -1。"""
        js = _WEB_FIND_VIDEO + "return v?String(v.currentTime):'-1';})()"
        try:
            return float(web_js(js))
        except Exception:
            return -1.0

    def web_video_fallback():
        """视频迟迟不开始时的兜底：静音播放 + 关掉省流限制。

        手机浏览器（尤其 iOS / 微信内置浏览器）对带声音的自动播放限制很严，
        play() 被拒绝后就一直是黑屏。静音播放一定允许，先让画面动起来；
        用户点「继续」或画面时再恢复声音（由 movie_pause_apply 负责）。
        """
        if not renpy.emscripten:
            return

        js = (
            _WEB_FIND_VIDEO
            + "if(!v)return '0';try{"
            + "v.preload='auto';v.playsInline=true;v.setAttribute('playsinline','');"
            + "if(v.paused){v.muted=true;var p=v.play();"
            + "if(p&&p.catch)p.catch(function(){});}"
            + "}catch(e){}return '1';})()"
        )
        if web_js(js) == "1":
            renpy.notify("视频已静音播放（可点「继续」恢复声音）")

    def web_prompt(title="问史官", default=""):
        """弹浏览器原生输入框，返回用户输入的文字。

        - 返回 None：不在网页版里（调用方应走本地逻辑）
        - 返回 ""：用户点了取消或没输入
        用原生输入框是因为 canvas 里的 input 收不到中文输入法。
        """
        if not renpy.emscripten:
            return None

        js = (
            "(function(){var s=window.prompt(%s,%s);"
            "return (s===null)?'__CANCEL__':s;})()"
        ) % (
            _json.dumps(title, ensure_ascii=False),
            _json.dumps(default, ensure_ascii=False),
        )

        r = web_js(js)
        if r == "__CANCEL__":
            return ""
        return r
