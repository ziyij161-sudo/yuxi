default torch_current_char = -1
default torch_can_take_photo = False
default show_info = False
default info_text = ""

# ID映射：0秦始皇，1王政君，2王莽，3刘秀，4李从珂

# 番外「历史朋友圈」的五位人物
# 每项：立绘路径 / 名字 / 横向位置 / 一句话简介
init python:
    TORCH_PORTRAITS = [
        ("images/game_06/qin_shihuang.png", "秦始皇", 0.08,
         "秦始皇\n\n传国玉玺的缔造者。他统一天下后，命人将和氏璧雕琢为传国玉玺，作为皇权正统的象征。"),
        ("images/game_06/wang_zhengjun.png", "王政君", 0.29,
         "王政君\n\n西汉太后。王莽索要玉玺时，她愤怒地将玉玺摔在地上，磕坏了玉玺一角，后来缺角以黄金修补。"),
        ("images/game_06/wang_mang.png", "王莽", 0.50,
         "王莽\n\n新朝建立者。他逼王政君交出玉玺，拿到缺角的玉玺后，用黄金修补，是玉玺历史上的重要转折人物。"),
        ("images/game_06/liu_xiu.png", "刘秀", 0.71,
         "刘秀\n\n东汉开国皇帝。王莽败亡后，传国玉玺几经辗转，最终归于刘秀，玉玺重回汉室。"),
        ("images/game_06/li_congke.png", "李从珂", 0.92,
         "李从珂\n\n后唐末帝。936年，他携传国宝登上玄武楼自焚，此后传国玉玺下落不明。"),
    ]

# 照片淡入
# 原来这里有个"快门闪光"：一层 1280×720 的纯白遮罩闪一下再消失。
# 问题有两个：一是尺寸不是全屏，屏幕上是一块白方框跳过去，看着像画面出错；
# 二是照片紧接着就硬切出来，白→照片的亮度跳变很刺眼。
# 现在改成照片自己从透明淡入，快门声保留，观感是"拍完显影"而不是"闪一下白"。
transform photo_fade_in:
    alpha 0.0
    ease 0.35 alpha 1.0


# ================= 合影成品弹窗界面 =================

screen show_photo(photo_idx, photo_title):

    modal True

    add Transform("images/game_06/palace_bg.png", xysize=(config.screen_width, config.screen_height))

    # ================= 全屏合影照片 =================

    if photo_idx == 0:
        add "images/game_06/photo_01_qin.png" at photo_fade_in:
            xysize (config.screen_width, config.screen_height)

    elif photo_idx == 1:
        add "images/game_06/photo_02_wangzhengjun.png" at photo_fade_in:
            xysize (config.screen_width, config.screen_height)

    elif photo_idx == 2:
        add "images/game_06/photo_03_wangmang.png" at photo_fade_in:
            xysize (config.screen_width, config.screen_height)

    elif photo_idx == 3:
        add "images/game_06/photo_04_liuxiu.png" at photo_fade_in:
            xysize (config.screen_width, config.screen_height)

    elif photo_idx == 4:
        add "images/game_06/photo_05_licongke.png" at photo_fade_in:
            xysize (config.screen_width, config.screen_height)


    # 顶部信息框
    frame:
        xalign 0.5
        yalign 0.04
        xsize 960
        ysize 168
        background Frame("#493323EE", 15, 15)
        padding (25, 15)

        vbox:
            xalign 0.5
            yalign 0.5
            spacing 8

            # 人物名字
            if photo_idx == 0:
                text "秦始皇":
                    xalign 0.5
                    size 44
                    color "#e8d5a3"

            elif photo_idx == 1:
                text "王政君":
                    xalign 0.5
                    size 44
                    color "#e8d5a3"

            elif photo_idx == 2:
                text "王莽":
                    xalign 0.5
                    size 44
                    color "#e8d5a3"

            elif photo_idx == 3:
                text "刘秀":
                    xalign 0.5
                    size 44
                    color "#e8d5a3"

            elif photo_idx == 4:
                text "李从珂":
                    xalign 0.5
                    size 44
                    color "#e8d5a3"

            # 照片标题
            text "[photo_title]":
                xalign 0.5
                size 34
                color "#FFDD88"

            # 右上角返回宫殿按钮
    frame:
        xalign 0.96
        yalign 0.05
        xsize 190
        ysize 60
        background Frame("#493323EE", 12, 12)
        padding (8, 5)

        textbutton "返 回":
            style "game_button"
            xalign 0.5
            yalign 0.5
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            action Return()

# ================= 合影场景：人物 + 玉玺 =================

screen torch_meet_scene():

    on "show" action SetVariable("quick_menu", False)

    add Transform("images/game_06/palace_bg.png", xysize=(config.screen_width, config.screen_height))

    # 当前历史人物：显示在左侧
    if torch_current_char == 0:
        add "images/game_06/qin_shihuang.png":
            xpos 0.18
            ypos 1.02
            yanchor 1.0
            zoom 0.48

    elif torch_current_char == 1:
        add "images/game_06/wang_zhengjun.png":
            xpos 0.18
            ypos 1.02
            yanchor 1.0
            zoom 0.48

    elif torch_current_char == 2:
        add "images/game_06/wang_mang.png":
            xpos 0.18
            ypos 1.02
            yanchor 1.0
            zoom 0.48

    elif torch_current_char == 3:
        add "images/game_06/liu_xiu.png":
            xpos 0.18
            ypos 1.02
            yanchor 1.0
            zoom 0.48

    elif torch_current_char == 4:
        add "images/game_06/li_congke.png":
            xpos 0.18
            ypos 1.02
            yanchor 1.0
            zoom 0.48

    # 场景标题
    text "历史合影时间":
        xalign 0.5
        ypos 0.04
        size 48
        color "#e8d5a3"
        outlines [(2, "#493323", 0, 0)]



# ================= 合影操作按钮 =================

screen torch_meet_controls():

    modal True

    # 底部操作面板
    frame:
        xalign 0.5
        yalign 0.92
        xsize 780
        ysize 140
        background "#0d0a07e6"
        padding (20, 15)

        hbox:
            xalign 0.5
            yalign 0.5
            spacing 35

            # 拍照按钮
            textbutton "拍 照 留 念":
                style "game_button"
                xsize 300
                ysize 84
                text_size 34
                text_color "#e8d5a3"
                text_hover_color "#ffffff"
                text_xalign 0.5
                action Return("photo")

            # 返回按钮
            textbutton "返回人物选择":
                style "game_button"
                xsize 320
                ysize 84
                text_size 34
                text_color "#e8d5a3"
                text_hover_color "#ffffff"
                text_xalign 0.5
                action Return("back")

# ================= 宫殿人物选择界面 =================

screen torch_select_scene():

    modal True

    # 全屏立绘场景：关掉底部「回退/历史/快进」快捷条，避免压在人物身上
    on "show" action SetVariable("quick_menu", False)

    # 宫殿背景
    add Transform("images/game_06/palace_bg.png", xysize=(config.screen_width, config.screen_height))

    # 页面标题
    text "玉玺的历史朋友圈":
        xalign 0.5
        ypos 0.08
        size 56
        color "#e8d5a3"
        outlines [(2, "#493323", 0, 0)]

    text "选择一位历史人物，开启一段回忆":
        xalign 0.5
        ypos 0.17
        size 34
        color "#cbb98f"
        outlines [(2, "#493323", 0, 0)]

    # ================= 五位历史人物 =================
    # 立绘直接画在屏幕层：底边压到画面下沿之下 3%，保证与最下面严丝合缝、不留缝
    for entry in TORCH_PORTRAITS:
        add entry[0]:
            xalign entry[2]
            ypos 1.03
            yanchor 1.0
            zoom 0.40

    # 点击热区 + 头顶名牌
    for idx, entry in enumerate(TORCH_PORTRAITS):
        button:
            xalign entry[2]
            ypos 1.0
            yanchor 1.0
            xysize (330, 760)
            background None

            action [
                SetVariable("torch_current_char", idx),
                SetVariable("info_text", entry[3]),
                SetVariable("show_info", True)
            ]

            frame:
                xalign 0.5
                ypos 0
                xsize 150
                background Frame("#000000bb", 4, 4)
                padding (5, 5)

                text entry[1]:
                    xalign 0.5
                    color "#e8d5a3"
                    size 32
                    outlines [(1, "#000000", 0, 0)]

    # ================= 结束按钮 =================
    # 右上角结束番外按钮
    frame:
        xpos 0.90
        ypos 0.03
        xsize 220
        ysize 78
        background "#0d0a07e6"
        padding (8, 5)

        textbutton "结束番外":
            style "game_button"
            xalign 0.5
            yalign 0.5
            text_size 34
            text_color "#e8d5a3"
            text_hover_color "#ffffff"
            action Return("exit")
    # ================= 人物介绍弹窗 =================
    
    if show_info:
        frame:
            xalign 0.5
            ypos 0.56
            yanchor 0.5
            xsize 800
            ysize 560
            background Frame("#111111ee", 12, 12)
            padding (25, 20)
            vbox:
                xfill True
                yfill True
                spacing 10

                # 正文区域
                frame:
                    xfill True
                    ysize 380
                    background None
                    padding (12, 5)

                    text "[info_text]":
                        color "#e8d5a3"
                        size 32
                        xalign 0.5
                        yalign 0.2
                        text_align 0.5
                        line_spacing 10

                # 底部按钮方框
                frame:
                    xfill True
                    ysize 96
                    background Frame("#493D32", 8, 8)
                    padding (12, 10)

                    hbox:
                        xfill True
                        yalign 0.5
                        spacing 25

                        textbutton "关闭":
                            style "game_button"
                            xsize 220
                            ysize 68
                            text_size 32
                            text_color "#e8d5a3"
                            text_hover_color "#ffffff"
                            text_xalign 0.5
                            action SetVariable("show_info", False)

                        textbutton "和 我 合 影 吧":
                            style "game_button"
                            xsize 300
                            ysize 68
                            text_size 32
                            text_color "#e8d5a3"
                            text_hover_color "#ffffff"
                            text_xalign 0.5
                            background Frame("#B8794E", 8, 8)
                            action [
                                SetVariable("show_info", False),
                                Return(torch_current_char)
                            ]


          
# --------------------拍照逻辑，独立label--------------------
label do_take_photo:

    hide screen torch_meet_scene

    python:
        try:
            renpy.sound.play("audio/click_shutter.ogg")
        except Exception:
            pass

    # 快门声还在，但不闪白了：照片自己从透明淡入（见 photo_fade_in）
    pause 0.12

    # 对应照片标题
    $ photo_map = {
        0: "《天下初定》",
        1: "《金镶玉的由来》",
        2: "《金玉相逢》",
        3: "《汉室重光》",
        4: "《最后的留影》"
    }

    $ cid = torch_current_char
    $ title = photo_map[cid]

    # 展示提前制作好的完整合影
    call screen show_photo(cid, title)

    jump extra_loop

# ----------------对话标签----------------
label dialog_qin:
    "玉玺：始皇帝，好久不见！"
    "秦始皇：你这小家伙，倒是挺上镜。"
    "玉玺：那当然，我可是天下第一玺！"
    $ torch_can_take_photo = True
    return

label dialog_wangzhengjun:
    "玉玺：太后，听说您当年摔过我？"
    "王政君：谁让那些人非要抢我！"
    "玉玺：还好我只是缺了个角……"
    $ torch_can_take_photo = True
    return

label dialog_wangmang:
    "玉玺：听说我的缺角还是您给补的？"
    "王莽：黄金镶玉，岂不更显尊贵？"
    "玉玺：谢谢，突然感觉自己升值了！"
    $ torch_can_take_photo = True
    return

label dialog_liuxiu:
    "玉玺：兜兜转转，我终于回来了！"
    "刘秀：汉室中兴，也算是有你的见证。"
    "玉玺：这次可要好好保管我呀！"
    $ torch_can_take_photo = True
    return

label dialog_licongke:
    "玉玺：这次拍完，我们还能再见吗？"
    "李从珂：但愿后人还记得你。"
    "玉玺：那就把这张照片留下吧……"
    $ torch_can_take_photo = True
    return

# ----------------番外主入口----------------
label torch_extra:
    $ torch_current_char = -1
    $ torch_can_take_photo = False
    $ show_info = False
    # 番外是全屏立绘场景，底部快捷菜单会压在人物身上，这里先关掉
    $ quick_menu = False
    scene black
    with fade

    # 番外・照相馆：把全篇的舒缓配乐换成更轻快活泼的一首
    # （要换曲子，替换 audio/game_06/photo_lively.ogg 即可）
    stop music fadeout 1.5
    play music "audio/game_06/photo_lively.ogg" fadein 1.5 loop

    call screen chapter_intro(
        "番外　与君同照",
        "千年之后　・　一间没有人的照相馆",
        [
            "所有故事都已落幕。",
            "可那些人还站在原处，等着和你合一张影。",
        ],
        [
            "点击殿中的人物立绘，听他们说完最后一句话。",
            "选好之后点「拍 照 留 念」，这张照片会留在你的相册里。",
        ],
    )

label extra_loop:

    hide screen torch_meet_scene

    call screen torch_select_scene()
    $ res = _return

    if res == "exit":
        jump epilogue_end

    $ cid = res
    $ torch_current_char = cid
    $ torch_can_take_photo = False

    # 进入独立合影场景
    show screen torch_meet_scene

    # 根据人物播放对应对话
    if cid == 0:
        call dialog_qin
    elif cid == 1:
        call dialog_wangzhengjun
    elif cid == 2:
        call dialog_wangmang
    elif cid == 3:
        call dialog_liuxiu
    elif cid == 4:
        call dialog_licongke

    # 对话结束，等待玩家选择拍照或返回
    call screen torch_meet_controls()
    $ meet_choice = _return

    if meet_choice == "photo":
        jump do_take_photo
    else:
        jump extra_loop

# 番外收尾
label epilogue_end:
    scene black
    with fade
    stop music fadeout 3.0
    $ quick_menu = True
    centered "历史的故事已经结束，"
    centered "但关于它的记忆，仍在继续。"
    centered "—— 番外篇完 ——"
    jump real_ending

# 真结局：全剧终 → 制作名单 → 回主菜单
label real_ending:
    scene black
    with fade
    $ quick_menu = False
    centered "—— 全剧终 ——"
    # 制作名单（story_ui.rpy 的 credits_card），点击任意处结束
    call screen credits_card
    $ quick_menu = True
    scene black
    with fade
    # return 结束本轮游戏，回到主菜单
    return
